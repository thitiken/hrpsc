# ไฟล์ดีไซน์อ้างอิง (Approved Designs)

ไฟล์ HTML เหล่านี้คือ UI/UX ที่ผ่านการรีวิวแล้ว — ใช้เป็น **source of truth** เวลาสร้าง frontend จริง
เปิดในเบราว์เซอร์เพื่อดูการทำงานจริง (คลิกเมนู, สลับโหมดมืด, ลองกรอกฟอร์ม)

| ไฟล์ | คือหน้าอะไร | ดูอะไรเป็นหลัก |
|------|-------------|----------------|
| `HR Dashboard.html` | แดชบอร์ด + เมนู PA ทั้งหมด | layout, sidebar (ยุบได้), โหมดสว่าง/มืด, KPI, การ์ด |
| `pa-module.js` | logic หน้า PA (โหลดโดย dashboard) | **การไหลของสถานะ** ข้อตกลง→อนุมัติ 2 ขั้น→รายงาน 2 รอบ, ป๊อบอัปยืนยัน |
| `PA Committee Portal.html` | หน้ากรรมการให้คะแนน PA2 | ฟอร์มประเมิน 15 ตัวชี้วัด + คิดคะแนนสด, เลือกวิทยฐานะ |
| `Data Architecture.html` | เอกสารสถาปัตยกรรมเชิงภาพ | บทบาท, workflow, ERD (เวอร์ชันนำเสนอ) |

## วิธีใช้กับ Claude Code

- **อย่า** ก๊อปโค้ด HTML/JS เหล่านี้ไปตรง ๆ (เป็น prototype แบบ vanilla)
- **ให้** อ่านเพื่อเข้าใจ layout, สถานะ, การไหลของงาน, แล้วเขียนใหม่เป็น React component + เรียก API
- design tokens (สี/ฟอนต์/สถานะ) อยู่ใน `<style>` ของ `HR Dashboard.html` — ย้ายไป Tailwind config / CSS variables
- โหมดมืด: ดู `html[data-theme="dark"]` override ในไฟล์เดียวกัน

> โลโก้โรงเรียนอยู่ที่ `assets/logo-psc.png`
