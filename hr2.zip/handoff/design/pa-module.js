/* ===========================================================
   PA Module — บันทึกข้อตกลง PA1ส + รายงานผล 2 รอบ
   ผูกกับข้อมูลครูเจ้าของ user · เก็บแยกตามปีงบประมาณ
   ใช้ร่วมกับ HR Dashboard.html (render ใน #content)
   exposes: window.renderPA(), window.renderPAReports()
   =========================================================== */
(function(){
'use strict';

/* ---------- ข้อมูลครูเจ้าของ user (ผูกจากโปรไฟล์) ---------- */
const TEACHER = {
  prefix:'นาย', name:'ธิติวัฒน์ ทองคำ', pos:'ครู', vitha:'ยังไม่มีวิทยฐานะ',
  school:'โรงเรียนสิรินธรราชวิทยาลัย', area:'สพม. นครปฐม',
  dept:'กลุ่มสาระการเรียนรู้วิทยาศาสตร์และเทคโนโลยี',
  kasa:'คศ.1', salary:'27,500',
};
const YEARS = [2569,2568,2567];
const STORE = 'pa-agreement-v1';

/* ---------- โครงสร้าง 3 ด้าน (ตาม PA1ส ส่วนที่ 1) ---------- */
const DANS = [
  {k:'d1', n:'1', name:'ด้านการจัดการเรียนรู้',
   scope:'สร้าง/พัฒนาหลักสูตร · ออกแบบการจัดการเรียนรู้ · จัดกิจกรรมการเรียนรู้ · สร้าง/พัฒนาสื่อ นวัตกรรม เทคโนโลยี · วัดและประเมินผล · ศึกษาวิเคราะห์เพื่อแก้ปัญหา · จัดบรรยากาศและพัฒนาคุณลักษณะผู้เรียน'},
  {k:'d2', n:'2', name:'ด้านการส่งเสริมและสนับสนุนการจัดการเรียนรู้',
   scope:'จัดทำข้อมูลสารสนเทศผู้เรียน/รายวิชา · ระบบดูแลช่วยเหลือผู้เรียน · งานวิชาการและงานอื่นของสถานศึกษา · ประสานความร่วมมือกับผู้ปกครอง ภาคีเครือข่าย'},
  {k:'d3', n:'3', name:'ด้านการพัฒนาตนเองและวิชาชีพ',
   scope:'พัฒนาตนเองอย่างเป็นระบบและต่อเนื่อง · มีส่วนร่วม PLC แลกเปลี่ยนเรียนรู้ทางวิชาชีพ · นำความรู้มาพัฒนาการจัดการเรียนรู้และนวัตกรรม'},
];
const ROOMS = ['ห้องเรียนวิชาสามัญ/วิชาพื้นฐาน','ห้องเรียนปฐมวัย','ห้องเรียนการศึกษาพิเศษ','ห้องเรียนสายวิชาชีพ','ห้องเรียนการศึกษานอกระบบ/ตามอัธยาศัย'];
const ROUNDS = [
  {k:'r1', n:'1', name:'รอบที่ 1', period:'1 ต.ค. 2568 – 31 มี.ค. 2569', due:'สิ้นเดือนมีนาคม', icon:'sun-medium'},
  {k:'r2', n:'2', name:'รอบที่ 2', period:'1 เม.ย. 2569 – 30 ก.ย. 2569', due:'สิ้นเดือนกันยายน', icon:'cloud-sun'},
];
const STATUS = {
  draft:           {t:'ร่าง',              cls:'p-amber', i:'pencil'},
  pending_head:    {t:'รอหัวหน้ากลุ่มสาระพิจารณา', cls:'p-blue',  i:'user-search'},
  pending_director:{t:'รอ ผอ. พิจารณา',    cls:'p-blue',  i:'clock-3'},
  approved:        {t:'เห็นชอบแล้ว',        cls:'p-green', i:'check-circle-2'},
  returned:        {t:'ตีกลับให้แก้ไข',     cls:'p-rose',  i:'corner-up-left'},
};

/* หัวหน้ากลุ่มสาระการเรียนรู้ (ผู้มีสิทธิ์ approve ขั้นแรก) */
const HEADS = [
  {id:'h1', name:'นางสุภาพร วิทยาเด่น', dept:'วิทยาศาสตร์และเทคโนโลยี'},
  {id:'h2', name:'นายอนุชา คณิตเลิศ', dept:'คณิตศาสตร์'},
  {id:'h3', name:'นางสาวพิมพ์ใจ ภาษางาม', dept:'ภาษาไทย'},
  {id:'h4', name:'นายวีรพล สังคมศึกษา', dept:'สังคมศึกษา ศาสนาและวัฒนธรรม'},
];
const DIRECTOR = 'ดร.มานพ บริหารเลิศ';
function headById(id){ return HEADS.find(h=>h.id===id)||HEADS[0]; }
const RSTATUS = {
  none:     {t:'ยังไม่รายงาน',    cls:'p-amber', i:'circle-dashed'},
  reported: {t:'ส่งให้กรรมการแล้ว',cls:'p-blue',  i:'send'},
  evaluated:{t:'กรรมการประเมินแล้ว',cls:'p-green',i:'award'},
};

/* ---------- state (per year) ---------- */
let YEAR = YEARS[0];
const all = load();
function blank(){
  return {
    info:{dateFrom:'1 ตุลาคม 2568', dateTo:'30 กันยายน 2569', kasa:TEACHER.kasa, salary:TEACHER.salary, rooms:['ห้องเรียนวิชาสามัญ/วิชาพื้นฐาน']},
    workload:{teach:'18', subjects:[{name:'วิทยาศาสตร์ ม.2', hours:'12'},{name:'วิทยาการคำนวณ ม.3', hours:'6'}], support:'4', quality:'3', policy:'2'},
    s1:{d1:{tasks:'',out:'',ind:''}, d2:{tasks:'',out:'',ind:''}, d3:{tasks:'',out:'',ind:''}},
    s2:{topic:'', problem:'', method:'', quant:'', qual:''},
    status:'draft',
    approverId:'h1', isHead:false, returnedBy:'', returnNote:'',
    review:{head:{by:'', note:''}, director:{note:''}},
    reports:{r1:{status:'none', notes:{d1:'',d2:'',d3:'',s2:''}}, r2:{status:'none', notes:{d1:'',d2:'',d3:'',s2:''}}},
  };
}
function cur(){ if(!all[YEAR]) all[YEAR]=blank(); migrate(all[YEAR]); return all[YEAR]; }
/* รองรับข้อมูลเดิม + เติมฟิลด์ใหม่ที่ขาด */
function migrate(d){
  const b = blank();
  if(d.approverId==null) d.approverId=b.approverId;
  if(d.isHead==null) d.isHead=b.isHead;
  if(d.returnedBy==null) d.returnedBy='';
  if(d.returnNote==null) d.returnNote='';
  if(!d.review) d.review=b.review;
  else { if(!d.review.head) d.review.head={by:'',note:''}; if(!d.review.director) d.review.director={note:''}; }
  // map สถานะเก่า → สถานะใหม่
  if(!STATUS[d.status]){
    d.status = d.status==='submitted' ? 'pending_director' : 'draft';
  }
}
function load(){ try{ return JSON.parse(localStorage.getItem(STORE)||'{}'); }catch(e){ return {}; } }
function save(){ try{ localStorage.setItem(STORE, JSON.stringify(all)); }catch(e){} }
function esc(s){ return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

/* ---------- inject styles once ---------- */
function injectCSS(){
  if(document.getElementById('pa-css')) return;
  const s = document.createElement('style'); s.id='pa-css';
  s.textContent = `
  .pa-wrap{max-width:1080px}
  .pa-bar{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:20px}
  .pa-bar .yr{display:flex;align-items:center;gap:9px;background:var(--surface);border:1px solid var(--line);
    border-radius:13px;padding:9px 15px;box-shadow:var(--shadow-soft)}
  .pa-bar .yr label{font-size:12.5px;color:var(--muted);font-weight:600}
  .pa-bar .yr select{font-family:"Prompt",sans-serif;font-size:15px;font-weight:600;color:var(--brand);border:none;background:none;outline:none;cursor:pointer}
  .pa-bar .sp{flex:1}
  .pa-status{display:inline-flex;align-items:center;gap:7px;font-size:13px;font-weight:600;padding:8px 15px;border-radius:999px}
  .pa-status i{font-size:16px}
  .pa-id{background:var(--surface);border:1px solid var(--line);border-radius:13px;padding:9px 16px;font-size:13px;color:var(--ink-2);box-shadow:var(--shadow-soft)}
  .pa-id b{color:var(--ink);font-weight:600}

  .pa-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);box-shadow:var(--shadow-soft);margin-bottom:18px;overflow:hidden}
  .pa-card .ph{display:flex;align-items:center;gap:12px;padding:17px 22px;border-bottom:1px solid var(--line-2);background:linear-gradient(100deg,var(--brand-soft),transparent)}
  .pa-card .ph .pn{width:30px;height:30px;border-radius:9px;flex:0 0 30px;background:linear-gradient(135deg,var(--brand),var(--brand-400));color:#fff;
    font-family:"Prompt";font-weight:600;font-size:14px;display:flex;align-items:center;justify-content:center}
  .pa-card .ph h3{font-family:"Prompt";font-size:16px;font-weight:600;flex:1;letter-spacing:-.01em}
  .pa-card .ph .sub{font-size:12px;color:var(--muted)}
  .pa-card .pb{padding:18px 22px}

  .id-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
  .id-cell .l{font-size:11.5px;color:var(--muted);font-weight:600}
  .id-cell .v{font-size:14.5px;color:var(--ink);font-weight:500;margin-top:2px}

  .pa-field{margin-bottom:15px}
  .pa-field:last-child{margin-bottom:0}
  .pa-field > label{display:block;font-size:13px;font-weight:600;color:var(--ink-2);margin-bottom:6px}
  .pa-field .hint{font-weight:400;color:var(--muted);font-size:12px}
  .pa-input,.pa-ta{width:100%;font-family:"IBM Plex Sans Thai",sans-serif;font-size:14px;color:var(--ink);
    border:1.5px solid var(--line);border-radius:11px;padding:10px 13px;background:var(--surface);outline:none;transition:border-color .15s}
  .pa-input:focus,.pa-ta:focus{border-color:var(--brand)}
  .pa-ta{resize:vertical;min-height:74px;line-height:1.55}
  .pa-inline{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .pa-inline .pa-input{width:auto;flex:1;min-width:120px}
  .unit{font-size:13px;color:var(--muted);white-space:nowrap}

  .rooms{display:flex;flex-wrap:wrap;gap:9px}
  .room{display:flex;align-items:center;gap:8px;font-size:13px;border:1.5px solid var(--line);border-radius:999px;
    padding:8px 14px;cursor:pointer;transition:all .14s;user-select:none;color:var(--ink-2)}
  .room:hover{border-color:var(--brand-400)}
  .room.on{background:var(--brand-soft);border-color:var(--brand);color:var(--brand-700);font-weight:600}
  .room i{font-size:15px;opacity:0}
  .room svg{opacity:0}
  .room.on i,.room.on svg{opacity:1;color:var(--brand)}

  .subj-rows{display:flex;flex-direction:column;gap:9px}
  .subj-row{display:flex;align-items:center;gap:10px}
  .subj-row .pa-input{flex:1}
  .subj-row .sh{width:92px;flex:0 0 92px}
  .subj-del{width:38px;height:38px;flex:0 0 38px;border:1px solid var(--line);border-radius:10px;background:var(--surface);
    color:var(--rose);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .subj-del:hover{background:var(--rose-bg)}
  .subj-add{display:inline-flex;align-items:center;gap:7px;margin-top:10px;font-size:13px;font-weight:600;color:var(--brand);
    background:none;border:1px dashed var(--brand-400);border-radius:10px;padding:8px 14px;cursor:pointer;font-family:inherit}
  .subj-add:hover{background:var(--brand-soft)}
  .subj-add i{font-size:16px}

  .dan{border:1px solid var(--line);border-radius:14px;padding:0;margin-bottom:14px;overflow:hidden}
  .dan:last-child{margin-bottom:0}
  .dan-h{display:flex;align-items:center;gap:11px;padding:13px 16px;background:var(--surface-2);border-bottom:1px solid var(--line-2)}
  .dan-h .dn{width:26px;height:26px;border-radius:8px;flex:0 0 26px;background:var(--brand-soft);color:var(--brand);
    font-family:"Prompt";font-weight:600;font-size:13px;display:flex;align-items:center;justify-content:center}
  .dan-h .dt{font-family:"Prompt";font-size:14.5px;font-weight:600;color:var(--ink)}
  .dan-scope{font-size:11.5px;color:var(--muted);padding:10px 16px 4px;line-height:1.5}
  .dan-body{padding:6px 16px 16px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
  .dan-body .pa-field > label{font-size:12px}

  .sum-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .sum-box{border:1px solid var(--line);border-radius:12px;padding:13px 15px}
  .sum-box .sl{font-size:12px;color:var(--muted);font-weight:600;display:flex;align-items:center;gap:7px}
  .sum-box .sl i{font-size:15px;color:var(--brand)}
  .sum-box .sv{font-size:14px;color:var(--ink);margin-top:6px;line-height:1.55;white-space:pre-wrap;min-height:20px}
  .sum-box .sv.empty{color:var(--muted);font-style:italic}

  .pa-actions{display:flex;gap:11px;flex-wrap:wrap;margin-top:6px}
  .pa-btn{display:inline-flex;align-items:center;gap:8px;padding:12px 22px;border-radius:13px;font-family:inherit;
    font-size:14.5px;font-weight:600;cursor:pointer;border:none;transition:transform .12s,box-shadow .16s,background .16s}
  .pa-btn:active{transform:translateY(1px)}
  .pa-btn i{font-size:18px}
  .pa-btn.primary{background:linear-gradient(100deg,var(--brand),var(--brand-600));color:#fff;box-shadow:0 8px 20px oklch(0.52 0.17 292 / .3)}
  .pa-btn.ghost{background:var(--surface);color:var(--ink-2);border:1px solid var(--line)}
  .pa-btn.ghost:hover{background:var(--surface-2)}

  .dir-note{display:flex;gap:11px;padding:14px 17px;border-radius:13px;background:var(--brand-soft);border:1px solid var(--brand-soft-2);font-size:13px;color:var(--ink-2);margin-top:4px}
  .dir-note i{font-size:18px;color:var(--brand);flex:0 0 auto;margin-top:1px}
  .dir-note.ok{background:var(--green-bg);border-color:oklch(0.88 0.05 155)}
  .dir-note.ok i{color:var(--green)}

  .pa-check{display:flex;align-items:flex-start;gap:10px;font-size:13px;color:var(--ink-2);cursor:pointer;padding:11px 14px;
    border:1px solid var(--line);border-radius:11px;background:var(--surface-2);line-height:1.5}
  .pa-check input{width:18px;height:18px;margin-top:1px;accent-color:var(--brand);flex:0 0 auto;cursor:pointer}
  .pa-check b{color:var(--ink);font-weight:600}

  .chain{display:flex;flex-direction:column}
  .chain-step{display:flex;gap:14px;position:relative}
  .cs-rail{flex:0 0 36px;display:flex;flex-direction:column;align-items:center}
  .cs-dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex:0 0 36px;
    border:2px solid var(--line);background:var(--surface);color:var(--muted);z-index:2}
  .cs-dot i{font-size:18px}
  .chain-step:not(:last-child) .cs-rail::after{content:"";width:2px;flex:1;background:var(--line);margin:2px 0;min-height:18px}
  .chain-step.done .cs-dot{background:var(--green);border-color:var(--green);color:#fff}
  .chain-step.done:not(:last-child) .cs-rail::after{background:var(--green)}
  .chain-step.active .cs-dot{background:var(--brand);border-color:var(--brand);color:#fff;box-shadow:0 0 0 4px var(--brand-soft)}
  .chain-step.ret .cs-dot{background:var(--rose);border-color:var(--rose);color:#fff}
  .chain-step.skip .cs-dot{border-style:dashed;background:var(--surface-2)}
  .cs-body{flex:1;padding-bottom:18px;min-width:0}
  .chain-step:last-child .cs-body{padding-bottom:0}
  .cs-top{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
  .cs-role{font-size:11.5px;color:var(--muted);font-weight:600}
  .cs-name{font-size:14.5px;color:var(--ink);font-weight:600;font-family:"Prompt";margin-top:1px}
  .cs-note{font-size:12.5px;color:var(--ink-2);margin-top:7px;padding:9px 13px;background:var(--surface-2);border-radius:10px;border-left:3px solid var(--brand-400)}
  .chain-step.ret .cs-note{border-left-color:var(--rose);background:var(--rose-bg)}

  /* ===== success modal ===== */
  .pa-modal-ov{position:fixed;inset:0;z-index:300;display:flex;align-items:center;justify-content:center;padding:20px;
    background:oklch(0.25 0.04 292 / 0);backdrop-filter:blur(0px);transition:background .22s,backdrop-filter .22s}
  .pa-modal-ov.show{background:oklch(0.25 0.04 292 / .42);backdrop-filter:blur(4px)}
  .pa-modal{background:var(--surface);border-radius:24px;width:100%;max-width:440px;padding:34px 30px 26px;position:relative;
    box-shadow:0 30px 80px oklch(0.3 0.1 292 / .4);text-align:center;
    transform:translateY(24px) scale(.96);opacity:0;transition:transform .28s cubic-bezier(.2,.9,.3,1.1),opacity .28s}
  .pa-modal-ov.show .pa-modal{transform:translateY(0) scale(1);opacity:1}
  .pm-x{position:absolute;top:16px;right:16px;width:34px;height:34px;border-radius:50%;border:none;background:var(--surface-2);
    color:var(--muted);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
  .pm-x:hover{background:var(--line);color:var(--ink)}
  .pm-x i{width:18px;height:18px}
  .pm-check{width:78px;height:78px;margin:0 auto 18px;border-radius:50%;background:var(--green-bg);
    display:flex;align-items:center;justify-content:center}
  .pm-check svg{width:54px;height:54px}
  .pm-check circle{fill:none;stroke:var(--green);stroke-width:3;opacity:.28;
    stroke-dasharray:151;stroke-dashoffset:151;animation:pm-circ .5s ease forwards}
  .pm-check path{fill:none;stroke:var(--green);stroke-width:4;stroke-linecap:round;stroke-linejoin:round;
    stroke-dasharray:44;stroke-dashoffset:44;animation:pm-tick .4s .3s ease forwards}
  @keyframes pm-circ{to{stroke-dashoffset:0}}
  @keyframes pm-tick{to{stroke-dashoffset:0}}
  .pm-title{font-family:"Prompt",sans-serif;font-size:21px;font-weight:600;color:var(--ink);letter-spacing:-.01em}
  .pm-sub{font-size:13.5px;color:var(--muted);margin-top:5px}
  .pm-task{background:var(--surface-2);border:1px solid var(--line);border-radius:15px;padding:15px 17px;margin:20px 0 0;text-align:right}
  .pm-task-l{display:flex;align-items:center;gap:7px;font-size:11.5px;font-weight:600;color:var(--brand);justify-content:flex-end}
  .pm-task-l i{width:15px;height:15px}
  .pm-task-v{font-family:"Prompt",sans-serif;font-size:15px;font-weight:600;color:var(--ink);margin-top:6px;line-height:1.45;text-align:right}
  .pm-meta{display:flex;align-items:center;gap:8px;justify-content:flex-end;font-size:12.5px;color:var(--ink-2);margin-top:9px;
    padding-top:9px;border-top:1px dashed var(--line)}
  .pm-meta:first-of-type{}
  .pm-meta i{width:15px;height:15px;color:var(--muted);flex:0 0 auto}
  .pm-meta b{color:var(--ink);font-weight:600}
  .pm-note{display:flex;align-items:flex-start;gap:9px;text-align:right;font-size:12.5px;color:var(--ink-2);
    background:var(--brand-soft);border-radius:12px;padding:11px 14px;margin-top:14px;line-height:1.5}
  .pm-note i{width:16px;height:16px;color:var(--brand);flex:0 0 auto;margin-top:2px}
  .pm-actions{display:flex;gap:10px;margin-top:22px}
  .pm-actions .pa-btn{flex:1;justify-content:center}
  /* confirm-ask variant */
  .pm-ask{width:78px;height:78px;margin:0 auto 18px;border-radius:50%;background:var(--brand-soft);
    display:flex;align-items:center;justify-content:center}
  .pm-ask i{width:38px;height:38px;color:var(--brand)}
  .pa-btn.danger{background:var(--rose);color:#fff;box-shadow:0 8px 20px oklch(0.6 0.16 18 / .28)}

  /* reports */
  .rep-tabs{display:flex;gap:10px;margin-bottom:18px}
  .rep-tab{flex:1;display:flex;align-items:center;gap:12px;padding:15px 18px;border-radius:var(--r-md);border:1.5px solid var(--line);
    background:var(--surface);cursor:pointer;transition:all .15s;text-align:right}
  .rep-tab:hover{border-color:var(--brand-400)}
  .rep-tab.on{border-color:var(--brand);background:linear-gradient(120deg,var(--brand-soft),var(--surface));box-shadow:0 6px 16px oklch(0.52 0.17 292 / .12)}
  .rep-tab .ri{width:42px;height:42px;border-radius:12px;flex:0 0 42px;display:flex;align-items:center;justify-content:center;
    background:var(--brand-soft);color:var(--brand)}
  .rep-tab.on .ri{background:linear-gradient(135deg,var(--brand),var(--brand-400));color:#fff}
  .rep-tab .ri i{font-size:21px}
  .rep-tab .rinfo{flex:1;min-width:0}
  .rep-tab .rinfo .rn{font-family:"Prompt";font-size:15px;font-weight:600;color:var(--ink)}
  .rep-tab .rinfo .rp{font-size:11.5px;color:var(--muted);margin-top:1px}

  .rep-dan{border:1px solid var(--line);border-radius:13px;padding:15px 16px;margin-bottom:13px}
  .rep-dan .rdh{display:flex;align-items:flex-start;gap:11px;margin-bottom:10px}
  .rep-dan .rdh .dn{width:26px;height:26px;border-radius:8px;flex:0 0 26px;background:var(--brand-soft);color:var(--brand);
    font-family:"Prompt";font-weight:600;font-size:13px;display:flex;align-items:center;justify-content:center;margin-top:1px}
  .rep-dan .rdh .rdt{flex:1}
  .rep-dan .rdh .rdt .nm{font-family:"Prompt";font-size:14px;font-weight:600}
  .rep-dan .rdh .rdt .plan{font-size:12px;color:var(--muted);margin-top:3px;line-height:1.5}
  .rep-dan .rdh .rdt .plan b{color:var(--ink-2);font-weight:600}

  @media(max-width:760px){
    .id-grid{grid-template-columns:1fr 1fr}
    .dan-body{grid-template-columns:1fr}
    .sum-grid{grid-template-columns:1fr}
    .rep-tabs{flex-direction:column}
    .subj-row .sh{width:74px;flex-basis:74px}
  }`;
  document.head.appendChild(s);
}

/* ---------- approval chain (ผู้จัดทำ → หัวหน้ากลุ่มสาระ → ผอ.) ---------- */
function chainStep(state, icon, role, name, note){
  const map = {
    done:   {dot:'check', cls:'done',   tag:'เห็นชอบแล้ว',   tcls:'p-green'},
    active: {dot:icon,     cls:'active', tag:'กำลังพิจารณา',  tcls:'p-blue'},
    wait:   {dot:icon,     cls:'wait',   tag:'รอตามลำดับ',    tcls:''},
    skip:   {dot:'minus',  cls:'skip',   tag:'ข้าม (ผู้จัดทำเป็นหัวหน้าเอง)', tcls:''},
    ret:    {dot:'corner-up-left', cls:'ret', tag:'ตีกลับให้แก้ไข', tcls:'p-rose'},
  };
  const m = map[state];
  return `<div class="chain-step ${m.cls}">
    <div class="cs-rail"><div class="cs-dot"><i data-lucide="${m.dot}"></i></div></div>
    <div class="cs-body">
      <div class="cs-top"><div><div class="cs-role">${role}</div><div class="cs-name">${esc(name)}</div></div>
        ${m.tag?`<span class="pa-status ${m.tcls}" style="padding:4px 11px;font-size:11.5px">${m.tag}</span>`:''}</div>
      ${note?`<div class="cs-note">“${esc(note)}”</div>`:''}
    </div>
  </div>`;
}
function chainHTML(d){
  const head = headById(d.approverId);
  const submitted = d.status!=='draft';
  // step states
  let s1='wait', s2='wait', s3='wait';
  if(submitted) s1='done';
  if(d.isHead){ s2='skip'; } else {
    if(d.status==='pending_head') s2='active';
    else if(d.status==='pending_director'||d.status==='approved') s2='done';
    else if(d.status==='returned'&&d.returnedBy==='head') s2='ret';
  }
  if(d.status==='pending_director') s3='active';
  else if(d.status==='approved') s3='done';
  else if(d.status==='returned'&&d.returnedBy==='director') s3='ret';

  const steps = [
    chainStep(s1,'user-round','ผู้จัดทำข้อตกลง', TEACHER.prefix+TEACHER.name+' · '+TEACHER.pos, ''),
  ];
  if(!d.isHead) steps.push(chainStep(s2,'user-search','หัวหน้ากลุ่มสาระ '+head.dept, head.name, d.returnedBy==='head'?d.returnNote:(d.status==='pending_director'||d.status==='approved'?d.review.head.note:'')));
  else steps.push(chainStep('skip','minus','หัวหน้ากลุ่มสาระ', 'ผู้จัดทำเป็นหัวหน้ากลุ่มสาระเอง — ส่งตรงให้ ผอ.', ''));
  steps.push(chainStep(s3,'user-check','ผู้อำนวยการสถานศึกษา', DIRECTOR, d.returnedBy==='director'?d.returnNote:(d.status==='approved'?d.review.director.note:'')));

  return `<div class="pa-card">
    <div class="ph"><div class="pn"><i data-lucide="git-merge" style="width:16px;height:16px"></i></div>
      <h3>สายการพิจารณาเห็นชอบข้อตกลง</h3><span class="sub">2 ขั้น · หัวหน้ากลุ่มสาระ → ผู้อำนวยการ</span></div>
    <div class="pb">
      ${d.status==='draft' ? `
        <div class="pa-field"><label>ส่งให้หัวหน้ากลุ่มสาระท่านใดพิจารณา</label>
          <select class="pa-input" id="paApprover">
            ${HEADS.map(h=>`<option value="${h.id}" ${h.id===d.approverId?'selected':''}>${h.name} · กลุ่มสาระ${h.dept}</option>`).join('')}
          </select></div>
        <label class="pa-check"><input type="checkbox" id="paIsHead" ${d.isHead?'checked':''}/>
          <span>ผู้จัดทำเป็น<b>หัวหน้ากลุ่มสาระเอง</b> — ส่งตรงให้ผู้อำนวยการพิจารณา (ข้ามขั้นหัวหน้ากลุ่มสาระ)</span></label>
        <div style="height:14px"></div>` : ''}
      <div class="chain">${steps.join('')}</div>
    </div>
  </div>`;
}
function actionsHTML(d){
  let btns='';
  if(d.status==='draft'){
    btns = `<button class="pa-btn primary" id="paSubmit"><i data-lucide="send"></i>${d.isHead?'ส่งให้ผู้อำนวยการพิจารณา':'ส่งให้หัวหน้ากลุ่มสาระพิจารณา'}</button>`;
  } else if(d.status==='pending_head'){
    btns = `<button class="pa-btn primary" id="paHeadApprove"><i data-lucide="check-circle-2"></i>จำลอง: หัวหน้ากลุ่มสาระเห็นชอบ</button>
            <button class="pa-btn ghost" id="paReturn" data-by="head"><i data-lucide="corner-up-left"></i>จำลอง: ตีกลับ</button>
            <button class="pa-btn ghost" id="paWithdraw"><i data-lucide="undo-2"></i>ถอนกลับเป็นร่าง</button>`;
  } else if(d.status==='pending_director'){
    btns = `<button class="pa-btn primary" id="paDirApprove"><i data-lucide="check-circle-2"></i>จำลอง: ผอ. เห็นชอบ</button>
            <button class="pa-btn ghost" id="paReturn" data-by="director"><i data-lucide="corner-up-left"></i>จำลอง: ตีกลับ</button>`;
  } else if(d.status==='returned'){
    btns = `<button class="pa-btn primary" id="paResubmit"><i data-lucide="send"></i>แก้ไขแล้ว ส่งพิจารณาอีกครั้ง</button>
            <button class="pa-btn ghost" id="paWithdraw"><i data-lucide="pencil"></i>กลับไปแก้ไขร่าง</button>`;
  } else { /* approved */
    btns = `<button class="pa-btn primary" id="paGoReport"><i data-lucide="clipboard-check"></i>ไปหน้ารายงานผล</button>
            <button class="pa-btn ghost" id="paWithdraw"><i data-lucide="pencil"></i>แก้ไขข้อตกลง</button>`;
  }
  return `<div class="pa-actions">${btns}
    <button class="pa-btn ghost" id="paSave"><i data-lucide="save"></i>บันทึกร่าง</button></div>`;
}

/* =========================================================
   PAGE 1 — บันทึกข้อตกลง PA1ส
   ========================================================= */
window.renderPA = function(){
  injectCSS();
  const d = cur();
  const st = STATUS[d.status];
  const roomChips = ROOMS.map(r=>`<div class="room ${d.info.rooms.includes(r)?'on':''}" data-room="${esc(r)}"><i data-lucide="check"></i>${r}</div>`).join('');
  const subjRows = d.workload.subjects.map((s,i)=>`
    <div class="subj-row" data-i="${i}">
      <input class="pa-input" data-w="subjects.${i}.name" value="${esc(s.name)}" placeholder="กลุ่มสาระ/รายวิชา" />
      <input class="pa-input sh" data-w="subjects.${i}.hours" value="${esc(s.hours)}" placeholder="ชม." />
      <button class="subj-del" data-del="${i}"><i data-lucide="trash-2"></i></button>
    </div>`).join('');

  const danCards = DANS.map(D=>`
    <div class="dan">
      <div class="dan-h"><div class="dn">${D.n}</div><div class="dt">${D.name}</div></div>
      <div class="dan-scope">${D.scope}</div>
      <div class="dan-body">
        <div class="pa-field"><label>งาน (Tasks) ที่จะพัฒนา</label>
          <textarea class="pa-ta" data-s1="${D.k}.tasks" placeholder="ระบุงานที่จะดำเนินการ">${esc(d.s1[D.k].tasks)}</textarea></div>
        <div class="pa-field"><label>ผลลัพธ์ (Outcomes) ที่คาดหวัง</label>
          <textarea class="pa-ta" data-s1="${D.k}.out" placeholder="ผลที่คาดหวังกับผู้เรียน">${esc(d.s1[D.k].out)}</textarea></div>
        <div class="pa-field"><label>ตัวชี้วัด (Indicators)</label>
          <textarea class="pa-ta" data-s1="${D.k}.ind" placeholder="ตัวชี้วัดที่เกิดกับผู้เรียน">${esc(d.s1[D.k].ind)}</textarea></div>
      </div>
    </div>`).join('');

  return `<div class="pa-wrap">
    <div class="pa-bar">
      <div class="yr"><label>ปีงบประมาณ</label>
        <select id="paYear">${YEARS.map(y=>`<option value="${y}" ${y===YEAR?'selected':''}>พ.ศ. ${y}</option>`).join('')}</select>
      </div>
      <span class="pa-id">ผู้จัดทำ: <b>${TEACHER.prefix}${TEACHER.name}</b> · ${TEACHER.pos} (${TEACHER.vitha})</span>
      <span class="sp"></span>
      <span class="pa-status ${st.cls}"><i data-lucide="${st.i}"></i>${st.t}</span>
    </div>

    <div class="pa-card">
      <div class="ph"><div class="pn"><i data-lucide="id-card" style="width:16px;height:16px"></i></div>
        <h3>ข้อมูลผู้จัดทำข้อตกลง</h3><span class="sub">ดึงจากข้อมูลบุคลากร</span></div>
      <div class="pb">
        <div class="id-grid">
          <div class="id-cell"><div class="l">ชื่อ–สกุล</div><div class="v">${TEACHER.prefix}${TEACHER.name}</div></div>
          <div class="id-cell"><div class="l">ตำแหน่ง / วิทยฐานะ</div><div class="v">${TEACHER.pos} · ${TEACHER.vitha}</div></div>
          <div class="id-cell"><div class="l">กลุ่มสาระ</div><div class="v">${TEACHER.dept}</div></div>
          <div class="id-cell"><div class="l">สถานศึกษา / สังกัด</div><div class="v">${TEACHER.school} · ${TEACHER.area}</div></div>
          <div class="id-cell"><div class="l">รับเงินเดือนอันดับ</div><div class="v">${TEACHER.kasa} · ${TEACHER.salary} บาท</div></div>
          <div class="id-cell"><div class="l">ช่วงข้อตกลง</div>
            <div class="v pa-inline" style="gap:6px"><input class="pa-input" style="width:auto;flex:1" data-info="dateFrom" value="${esc(d.info.dateFrom)}"/><span class="unit">ถึง</span><input class="pa-input" style="width:auto;flex:1" data-info="dateTo" value="${esc(d.info.dateTo)}"/></div></div>
        </div>
        <div class="pa-field" style="margin-top:16px"><label>ประเภทห้องเรียนที่จัดการเรียนรู้ <span class="hint">(เลือกได้มากกว่า 1)</span></label>
          <div class="rooms" id="paRooms">${roomChips}</div></div>
      </div>
    </div>

    <div class="pa-card">
      <div class="ph"><div class="pn">1</div><h3>ส่วนที่ 1 · ข้อตกลงการพัฒนางานตามมาตรฐานตำแหน่ง</h3></div>
      <div class="pb">
        <div class="pa-field"><label>1.1 ชั่วโมงสอนตามตารางสอน <span class="hint">(ชั่วโมง/สัปดาห์ แยกตามรายวิชา)</span></label>
          <div class="subj-rows" id="paSubjects">${subjRows}</div>
          <button class="subj-add" id="paAddSubj"><i data-lucide="plus"></i>เพิ่มรายวิชา</button>
          <div class="pa-inline" style="margin-top:12px"><span class="unit">รวมชั่วโมงสอน</span>
            <input class="pa-input" style="width:90px;flex:0 0 90px" data-w="teach" value="${esc(d.workload.teach)}"/><span class="unit">ชม./สัปดาห์</span></div>
        </div>
        <div class="id-grid" style="grid-template-columns:repeat(3,1fr)">
          <div class="pa-field"><label>1.2 งานส่งเสริมสนับสนุนฯ</label><div class="pa-inline"><input class="pa-input" data-w="support" value="${esc(d.workload.support)}"/><span class="unit">ชม./สัปดาห์</span></div></div>
          <div class="pa-field"><label>1.3 งานพัฒนาคุณภาพฯ</label><div class="pa-inline"><input class="pa-input" data-w="quality" value="${esc(d.workload.quality)}"/><span class="unit">ชม./สัปดาห์</span></div></div>
          <div class="pa-field"><label>1.4 งานตอบสนองนโยบายฯ</label><div class="pa-inline"><input class="pa-input" data-w="policy" value="${esc(d.workload.policy)}"/><span class="unit">ชม./สัปดาห์</span></div></div>
        </div>
        <div style="height:8px"></div>
        <label class="pa-field" style="display:block"><label style="font-size:13px;font-weight:600;color:var(--ink-2)">2. งานที่จะปฏิบัติตามมาตรฐานตำแหน่ง (3 ด้าน)</label></label>
        ${danCards}
      </div>
    </div>

    <div class="pa-card">
      <div class="ph"><div class="pn">2</div><h3>ส่วนที่ 2 · ประเด็นท้าทายในการพัฒนาผลลัพธ์การเรียนรู้</h3>
        <span class="sub">ระดับที่คาดหวัง: ปรับประยุกต์</span></div>
      <div class="pb">
        <div class="pa-field"><label>ประเด็นท้าทาย เรื่อง</label>
          <input class="pa-input" data-s2="topic" value="${esc(d.s2.topic)}" placeholder="ชื่อประเด็นท้าทายที่จะพัฒนา"/></div>
        <div class="pa-field"><label>1. สภาพปัญหาของผู้เรียนและการจัดการเรียนรู้</label>
          <textarea class="pa-ta" data-s2="problem">${esc(d.s2.problem)}</textarea></div>
        <div class="pa-field"><label>2. วิธีการดำเนินการให้บรรลุผล</label>
          <textarea class="pa-ta" data-s2="method">${esc(d.s2.method)}</textarea></div>
        <div class="sum-grid">
          <div class="pa-field"><label>3.1 ผลลัพธ์ที่คาดหวัง — เชิงปริมาณ</label>
            <textarea class="pa-ta" data-s2="quant">${esc(d.s2.quant)}</textarea></div>
          <div class="pa-field"><label>3.2 ผลลัพธ์ที่คาดหวัง — เชิงคุณภาพ</label>
            <textarea class="pa-ta" data-s2="qual">${esc(d.s2.qual)}</textarea></div>
        </div>
      </div>
    </div>

    ${chainHTML(d)}

    ${actionsHTML(d)}
  </div>`;
};

/* =========================================================
   PAGE 2 — รายงานผล 2 รอบ
   ========================================================= */
let REP_ROUND = 'r1';
window.renderPAReports = function(){
  injectCSS();
  const d = cur();
  if(d.status!=='approved'){
    return `<div class="pa-wrap">
      <div class="dir-note"><i data-lucide="lock"></i><div>ยังไม่มีข้อตกลง PA ที่ได้รับความเห็นชอบสำหรับปีงบประมาณ ${YEAR}<br/>กรุณาจัดทำและส่งข้อตกลงในเมนู “PA บันทึกข้อตกลง” ให้ผู้อำนวยการเห็นชอบก่อน จึงจะรายงานผลได้</div></div>
      <div class="pa-actions"><button class="pa-btn primary" id="repGoPA"><i data-lucide="file-check-2"></i>ไปหน้าบันทึกข้อตกลง</button></div>
    </div>`;
  }
  const R = ROUNDS.find(r=>r.k===REP_ROUND);
  const rep = d.reports[REP_ROUND];
  const rs = RSTATUS[rep.status];
  const tabs = ROUNDS.map(r=>{
    const st = RSTATUS[d.reports[r.k].status];
    return `<div class="rep-tab ${r.k===REP_ROUND?'on':''}" data-round="${r.k}">
      <div class="ri"><i data-lucide="${r.icon}"></i></div>
      <div class="rinfo"><div class="rn">${r.name} · รายงานผล</div><div class="rp">${r.period} · ครบกำหนด${r.due}</div></div>
      <span class="pa-status ${st.cls}" style="padding:5px 11px;font-size:11.5px"><i data-lucide="${st.i}" style="width:14px;height:14px"></i>${st.t}</span>
    </div>`;
  }).join('');

  const danReports = DANS.map(D=>`
    <div class="rep-dan">
      <div class="rdh"><div class="dn">${D.n}</div><div class="rdt">
        <div class="nm">${D.name}</div>
        <div class="plan"><b>งานตามข้อตกลง:</b> ${d.s1[D.k].tasks?esc(d.s1[D.k].tasks):'<span style="color:var(--muted)">— ยังไม่ได้ระบุในข้อตกลง —</span>'}</div>
      </div></div>
      <div class="pa-field"><label>ผลการปฏิบัติงานจริง / หลักฐานเชิงประจักษ์</label>
        <textarea class="pa-ta" data-rep="${D.k}" ${rep.status!=='none'?'disabled':''} placeholder="สรุปผลการดำเนินงานและผลลัพธ์ที่เกิดกับผู้เรียนในรอบนี้">${esc(rep.notes[D.k])}</textarea></div>
    </div>`).join('');

  return `<div class="pa-wrap">
    <div class="pa-bar">
      <div class="yr"><label>ปีงบประมาณ</label>
        <select id="repYear">${YEARS.map(y=>`<option value="${y}" ${y===YEAR?'selected':''}>พ.ศ. ${y}</option>`).join('')}</select></div>
      <span class="pa-id">ข้อตกลง PA: <b>${esc(d.s2.topic||'ประเด็นท้าทาย ปีงบฯ '+YEAR)}</b></span>
      <span class="sp"></span>
      <span class="pa-status p-green"><i data-lucide="check-circle-2"></i>ข้อตกลงเห็นชอบแล้ว</span>
    </div>

    <div class="rep-tabs">${tabs}</div>

    <div class="pa-card">
      <div class="ph"><div class="pn"><i data-lucide="${R.icon}" style="width:16px;height:16px"></i></div>
        <h3>${R.name} — รายงานผลการพัฒนางานตามข้อตกลง</h3><span class="sub">${R.period}</span></div>
      <div class="pb">
        ${danReports}
        <div class="rep-dan">
          <div class="rdh"><div class="dn"><i data-lucide="target" style="width:14px;height:14px"></i></div><div class="rdt">
            <div class="nm">ประเด็นท้าทาย</div>
            <div class="plan"><b>เรื่อง:</b> ${d.s2.topic?esc(d.s2.topic):'<span style="color:var(--muted)">— ยังไม่ได้ระบุ —</span>'}</div>
          </div></div>
          <div class="pa-field"><label>ผลลัพธ์การพัฒนาที่เกิดขึ้นจริง (เชิงปริมาณ/คุณภาพ)</label>
            <textarea class="pa-ta" data-rep="s2" ${rep.status!=='none'?'disabled':''} placeholder="รายงานผลลัพธ์ที่เกิดกับผู้เรียนเทียบกับเป้าหมายที่ตั้งไว้">${esc(rep.notes.s2)}</textarea></div>
        </div>
      </div>
    </div>

    ${rep.status==='none'
      ? `<div class="dir-note"><i data-lucide="info"></i><div>เมื่อกรอกผลครบถ้วนแล้ว กด “ส่งรายงานให้คณะกรรมการ” ระบบจะส่งต่อให้กรรมการประเมินตามแบบ PA2</div></div>
         <div class="pa-actions">
           <button class="pa-btn primary" id="repSubmit"><i data-lucide="send"></i>ส่งรายงาน${R.name}ให้คณะกรรมการ</button>
           <button class="pa-btn ghost" id="repSave"><i data-lucide="save"></i>บันทึกร่าง</button>
         </div>`
      : `<div class="dir-note ok"><i data-lucide="${rs.i}"></i><div><b>${rs.t}</b> — ส่ง${R.name}เข้าสู่กระบวนการประเมินของคณะกรรมการเรียบร้อยแล้ว</div></div>
         <div class="pa-actions">
           <a class="pa-btn primary" href="PA Committee Portal.html" target="_blank"><i data-lucide="external-link"></i>เปิดหน้ากรรมการประเมิน (PA2)</a>
           <button class="pa-btn ghost" id="repReopen"><i data-lucide="corner-up-left"></i>แก้ไขรายงาน</button>
         </div>`}
  </div>`;
};

/* =========================================================
   interaction (event delegation on #content)
   ========================================================= */
function setPath(obj, path, val){
  const ks = path.split('.'); let o = obj;
  for(let i=0;i<ks.length-1;i++){ o = o[ks[i]]; }
  o[ks[ks.length-1]] = val;
}
function bind(){
  const root = document.getElementById('content');
  if(!root || root.__paBound) return;
  root.__paBound = true;

  root.addEventListener('input', e=>{
    const d = cur();
    const t = e.target;
    if(t.dataset.info!=null){ d.info[t.dataset.info]=t.value; save(); }
    else if(t.dataset.w!=null){
      const p=t.dataset.w;
      if(p.startsWith('subjects.')){ const[,i,f]=p.split('.'); d.workload.subjects[+i][f]=t.value; }
      else d.workload[p]=t.value;
      save();
    }
    else if(t.dataset.s1!=null){ setPath(d.s1,t.dataset.s1,t.value); save(); }
    else if(t.dataset.s2!=null){ d.s2[t.dataset.s2]=t.value; save(); }
    else if(t.dataset.rep!=null){ d.reports[REP_ROUND].notes[t.dataset.rep]=t.value; save(); }
  });

  root.addEventListener('click', e=>{
    const d = cur();
    const room = e.target.closest('.room');
    if(room){ const r=room.dataset.room; const arr=d.info.rooms; const i=arr.indexOf(r);
      if(i<0) arr.push(r); else arr.splice(i,1); save(); room.classList.toggle('on'); return; }

    const del = e.target.closest('[data-del]');
    if(del){
      const i = +del.dataset.del; const nm = d.workload.subjects[i]?.name;
      const doDel = ()=>{ d.workload.subjects.splice(i,1); save(); window.__rerenderPA(); };
      if(nm && nm.trim()){
        confirmAsk({ title:'ลบรายวิชานี้?', icon:'trash-2', tone:'danger', confirmText:'ลบรายวิชา',
          body:'รายการที่ลบจะไม่สามารถกู้คืนได้', task:nm, onConfirm:doDel });
      } else { doDel(); }
      return; }
    if(e.target.closest('#paAddSubj')){ d.workload.subjects.push({name:'',hours:''}); save(); window.__rerenderPA(); return; }

    if(e.target.closest('#paSave')||e.target.closest('#repSave')){ save(); toast('บันทึกร่างเรียบร้อยแล้ว'); return; }
    if(e.target.closest('#paSubmit')){
      const toWhom = d.isHead ? `ผู้อำนวยการ${TEACHER.school}` : `หัวหน้ากลุ่มสาระ${headById(d.approverId).dept} (${headById(d.approverId).name})`;
      confirmAsk({
        title:'ยืนยันการส่งข้อตกลง',
        body:'เมื่อส่งแล้วจะไม่สามารถแก้ไขได้จนกว่าจะถูกตีกลับ',
        task:`ข้อตกลงในการพัฒนางาน (PA) ประจำปีงบประมาณ พ.ศ. ${YEAR}`,
        to: toWhom,
        confirmText:'ยืนยันส่ง',
        onConfirm:()=>{
          d.status = d.isHead ? 'pending_director' : 'pending_head';
          d.returnedBy=''; d.returnNote=''; save(); window.__rerenderPA();
          confirmSent({
            title:'ส่งข้อตกลงสำเร็จ',
            task:`ข้อตกลงในการพัฒนางาน (PA) ประจำปีงบประมาณ พ.ศ. ${YEAR}`,
            to: toWhom,
            note: d.isHead ? 'รอผู้อำนวยการพิจารณาเห็นชอบเป็นขั้นสุดท้าย' : 'หัวหน้ากลุ่มสาระจะพิจารณาก่อนส่งต่อให้ผู้อำนวยการ'
          });
        }
      }); return; }
    if(e.target.closest('#paResubmit')){
      const toWhom = d.isHead ? `ผู้อำนวยการ${TEACHER.school}` : `หัวหน้ากลุ่มสาระ${headById(d.approverId).dept} (${headById(d.approverId).name})`;
      confirmAsk({
        title:'ส่งฉบับแก้ไขอีกครั้ง',
        body:'ระบบจะส่งข้อตกลงฉบับที่แก้ไขเข้าสู่การพิจารณาใหม่',
        task:`ข้อตกลงในการพัฒนางาน (PA) ปีงบประมาณ พ.ศ. ${YEAR} (ฉบับแก้ไข)`,
        to: toWhom,
        confirmText:'ส่งอีกครั้ง',
        onConfirm:()=>{
          d.status = d.isHead ? 'pending_director' : 'pending_head';
          d.returnedBy=''; d.returnNote=''; save(); window.__rerenderPA();
          confirmSent({
            title:'ส่งพิจารณาอีกครั้งสำเร็จ',
            task:`ข้อตกลงในการพัฒนางาน (PA) ปีงบประมาณ พ.ศ. ${YEAR} (ฉบับแก้ไข)`,
            to: toWhom,
            note:'ระบบส่งฉบับที่แก้ไขเข้าสู่การพิจารณาใหม่เรียบร้อยแล้ว'
          });
        }
      }); return; }
    if(e.target.closest('#paHeadApprove')){
      d.review.head.by = headById(d.approverId).name;
      d.review.head.note = 'เห็นชอบ — งานสอดคล้องกับมาตรฐานตำแหน่ง';
      d.status='pending_director'; save(); window.__rerenderPA(); toast('หัวหน้ากลุ่มสาระเห็นชอบ · ส่งต่อให้ ผอ.'); return; }
    if(e.target.closest('#paDirApprove')){
      d.review.director.note = 'เห็นชอบให้เป็นข้อตกลงในการพัฒนางาน';
      d.status='approved'; save(); window.__rerenderPA(); toast('ผู้อำนวยการเห็นชอบข้อตกลงแล้ว'); return; }
    const ret = e.target.closest('#paReturn');
    if(ret){
      d.status='returned'; d.returnedBy=ret.dataset.by;
      d.returnNote = ret.dataset.by==='head' ? 'ขอให้ทบทวนตัวชี้วัดส่วนที่ 2 ให้ชัดเจนขึ้น' : 'ขอให้ปรับภาระงานให้สอดคล้องตามเกณฑ์';
      save(); window.__rerenderPA(); toast('ตีกลับให้ผู้จัดทำแก้ไข'); return; }
    if(e.target.closest('#paWithdraw')){ d.status='draft'; d.returnedBy=''; d.returnNote=''; save(); window.__rerenderPA(); return; }
    if(e.target.closest('#paGoReport')){ window.go&&window.go('reports'); return; }
    if(e.target.closest('#repGoPA')){ window.go&&window.go('pa'); return; }

    const tab = e.target.closest('.rep-tab');
    if(tab){ REP_ROUND=tab.dataset.round; window.__rerenderRep(); return; }
    if(e.target.closest('#repSubmit')){
      const R = ROUNDS.find(r=>r.k===REP_ROUND);
      confirmAsk({
        title:'ยืนยันการส่งรายงานผล',
        body:'เมื่อส่งแล้วช่องรายงานจะถูกล็อก และส่งต่อให้คณะกรรมการประเมินทันที',
        task:`รายงานผลการพัฒนางานตามข้อตกลง ${R.name} ประจำปีงบประมาณ พ.ศ. ${YEAR}`,
        to:'คณะกรรมการประเมิน (ตามแบบ PA2)',
        confirmText:'ยืนยันส่งรายงาน',
        onConfirm:()=>{
          d.reports[REP_ROUND].status='reported'; save(); window.__rerenderRep();
          confirmSent({
            title:'ส่งรายงานผลสำเร็จ',
            task:`รายงานผลการพัฒนางานตามข้อตกลง ${R.name} ประจำปีงบประมาณ พ.ศ. ${YEAR}`,
            to:'คณะกรรมการประเมิน (ตามแบบ PA2)',
            note:'คณะกรรมการจะพิจารณาให้คะแนนตามตัวชี้วัด แล้วสรุปผลการประเมิน',
            link:{href:'PA Committee Portal.html', label:'เปิดหน้ากรรมการประเมิน'}
          });
        }
      }); return; }
    if(e.target.closest('#repReopen')){ d.reports[REP_ROUND].status='none'; save(); window.__rerenderRep(); return; }
  });

  root.addEventListener('change', e=>{
    const d = cur();
    if(e.target.id==='paApprover'){ d.approverId=e.target.value; save(); }
    if(e.target.id==='paIsHead'){ d.isHead=e.target.checked; save(); window.__rerenderPA(); }
    if(e.target.id==='paYear'){ YEAR=+e.target.value; window.__rerenderPA(); }
    if(e.target.id==='repYear'){ YEAR=+e.target.value; window.__rerenderRep(); }
  });
}

window.__rerenderPA = function(){ const c=document.getElementById('content'); c.innerHTML=window.renderPA(); window.lucide&&lucide.createIcons(); };
window.__rerenderRep = function(){ const c=document.getElementById('content'); c.innerHTML=window.renderPAReports(); window.lucide&&lucide.createIcons(); };

/* ===== confirm-before-send dialog (ป๊อบอัปยืนยันก่อนส่ง) ===== */
function confirmAsk(opts){
  const o = Object.assign({title:'ยืนยันการส่ง', task:'', to:'', body:'', icon:'send', confirmText:'ยืนยันการส่ง', tone:'primary', onConfirm:()=>{}}, opts);
  let ov = document.getElementById('pa-modal');
  if(ov){ ov.remove(); }
  ov = document.createElement('div');
  ov.id='pa-modal'; ov.className='pa-modal-ov';
  ov.innerHTML = `
    <div class="pa-modal" role="dialog" aria-modal="true">
      <button class="pm-x" data-cancel aria-label="ปิด"><i data-lucide="x"></i></button>
      <div class="pm-ask"><i data-lucide="${o.icon}"></i></div>
      <div class="pm-title">${esc(o.title)}</div>
      ${o.body?`<div class="pm-sub">${esc(o.body)}</div>`:''}
      ${o.task?`<div class="pm-task">
        <div class="pm-task-l"><i data-lucide="file-text"></i>รายการที่จะส่ง</div>
        <div class="pm-task-v">${esc(o.task)}</div>
        ${o.to?`<div class="pm-meta"><i data-lucide="user-check"></i><span>ส่งถึง <b>${esc(o.to)}</b></span></div>`:''}
      </div>`:''}
      <div class="pm-actions">
        <button class="pa-btn ghost" data-cancel><i data-lucide="x"></i>ยกเลิก</button>
        <button class="pa-btn ${o.tone}" data-ok><i data-lucide="check"></i>${esc(o.confirmText)}</button>
      </div>
    </div>`;
  document.body.appendChild(ov);
  window.lucide&&lucide.createIcons();
  const close=()=>{ ov.classList.remove('show'); setTimeout(()=>ov.remove(),220); };
  ov.addEventListener('click',e=>{
    if(e.target===ov||e.target.closest('[data-cancel]')){ close(); return; }
    if(e.target.closest('[data-ok]')){ close(); setTimeout(()=>o.onConfirm(),180); }
  });
  document.addEventListener('keydown',function k(e){ if(e.key==='Escape'){ close(); document.removeEventListener('keydown',k);} });
  requestAnimationFrame(()=>ov.classList.add('show'));
}
window.__paConfirmAsk = confirmAsk;

/* ===== success confirmation modal (ป๊อบอัปยืนยันการส่งสำเร็จ) ===== */
function confirmSent(opts){
  const o = Object.assign({title:'ส่งคำขอสำเร็จ', task:'', to:'', note:'', primary:'รับทราบ', link:null}, opts);
  const now = new Date();
  const when = now.toLocaleDateString('th-TH-u-ca-buddhist',{day:'numeric',month:'long',year:'numeric'})
    + ' · ' + now.toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'}) + ' น.';
  let ov = document.getElementById('pa-modal');
  if(ov){ ov.remove(); }
  ov = document.createElement('div');
  ov.id='pa-modal'; ov.className='pa-modal-ov';
  ov.innerHTML = `
    <div class="pa-modal" role="dialog" aria-modal="true">
      <button class="pm-x" data-close aria-label="ปิด"><i data-lucide="x"></i></button>
      <div class="pm-check"><svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24"/><path d="M15 27 l8 8 l15 -16"/></svg></div>
      <div class="pm-title">${esc(o.title)}</div>
      <div class="pm-sub">ระบบได้รับและบันทึกการส่งของคุณเรียบร้อยแล้ว</div>
      <div class="pm-task">
        <div class="pm-task-l"><i data-lucide="file-check-2"></i>รายการที่ส่ง</div>
        <div class="pm-task-v">${esc(o.task)}</div>
        ${o.to?`<div class="pm-meta"><i data-lucide="send"></i><span>ส่งถึง <b>${esc(o.to)}</b></span></div>`:''}
        <div class="pm-meta"><i data-lucide="clock-3"></i><span>${when}</span></div>
      </div>
      ${o.note?`<div class="pm-note"><i data-lucide="info"></i><span>${esc(o.note)}</span></div>`:''}
      <div class="pm-actions">
        ${o.link?`<a class="pa-btn ghost" href="${o.link.href}" target="_blank"><i data-lucide="external-link"></i>${esc(o.link.label)}</a>`:''}
        <button class="pa-btn primary" data-close><i data-lucide="check"></i>${esc(o.primary)}</button>
      </div>
    </div>`;
  document.body.appendChild(ov);
  window.lucide&&lucide.createIcons();
  const close=()=>{ ov.classList.remove('show'); setTimeout(()=>ov.remove(),220); };
  ov.addEventListener('click',e=>{ if(e.target===ov||e.target.closest('[data-close]')) close(); });
  document.addEventListener('keydown',function esc2(e){ if(e.key==='Escape'){ close(); document.removeEventListener('keydown',esc2);} });
  requestAnimationFrame(()=>ov.classList.add('show'));
}
window.__paConfirmSent = confirmSent;

function toast(msg){
  let t=document.getElementById('pa-toast');
  if(!t){ t=document.createElement('div'); t.id='pa-toast'; t.style.cssText=
    'position:fixed;bottom:26px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--ink);color:#fff;'+
    'padding:13px 22px;border-radius:13px;font-family:"IBM Plex Sans Thai",sans-serif;font-size:14px;font-weight:500;'+
    'box-shadow:0 12px 32px rgba(0,0,0,.28);opacity:0;transition:all .3s;z-index:200;display:flex;align-items:center;gap:9px';
    document.body.appendChild(t); }
  t.innerHTML='<i data-lucide="check-circle-2" style="width:18px;height:18px;color:#7ee0a0"></i>'+msg;
  window.lucide&&lucide.createIcons();
  requestAnimationFrame(()=>{ t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)'; });
  clearTimeout(t.__h); t.__h=setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(20px)'; },2600);
}

bind();
document.addEventListener('DOMContentLoaded', bind);
})();
