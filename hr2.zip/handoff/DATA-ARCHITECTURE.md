# สถาปัตยกรรมข้อมูล — Data Architecture

> ระบบบริหารงานบุคลากร + ว.PA · ออกแบบแบบ **Database-per-Domain (Bounded Context)**

---

## หลักการออกแบบ (Design principles)

1. **แยกตามขอบเขตงาน (bounded context)** — แต่ละโดเมนเป็นเจ้าของข้อมูลตัวเอง (data ownership)
2. **ไม่มี FK ข้ามโดเมน** — อ้างอิงข้ามด้วย **UUID** ในระดับแอป (application-level reference) เท่านั้น
3. **Personnel เป็น master เดียว** — ข้อมูลคน "แหล่งความจริงเดียว" โดเมนอื่นเก็บแค่ `people_id`
4. **Platform เป็น cross-cutting** — workflow อนุมัติ, แจ้งเตือน, audit ใช้ร่วมทุกโดเมนแบบ polymorphic (`subject_type` + `subject_id`)
5. **เริ่มที่ modular monolith** — 1 PostgreSQL, 7 schema; โตแล้วค่อยแยก database/service (schema → db ได้ตรง ๆ)
6. **เวลา/ปฏิทินเป็น พ.ศ.** ในชั้น UI; เก็บใน DB เป็น `timestamptz` (UTC) เสมอ แปลงตอนแสดงผล

---

## แผนภาพระดับสูง (Context map)

```
                    ┌───────────────────────────────────────────┐
                    │            platform  (cross-cutting)        │
                    │   workflow · notifications · audit_logs     │
                    └───────────────────────────────────────────┘
                        ▲        ▲          ▲           ▲
        ┌───────────────┘        │          │           └───────────────┐
        │                        │          │                           │
  ┌───────────┐          ┌───────────┐ ┌───────────┐            ┌───────────┐
  │   leave   │          │ workorder │ │    pa     │            │  content  │
  └───────────┘          └───────────┘ └───────────┘            └───────────┘
        │                      │             │                        │
        └──────────────┬───────┴──────┬──────┴────────────────────────┘
                       ▼              ▼   (อ้างด้วย people_id เท่านั้น)
                 ┌───────────┐  ┌───────────┐
                 │ personnel │  │ identity  │   identity.user ⇄ personnel.person (1:1)
                 │ (master)  │  │  (auth)   │
                 └───────────┘  └───────────┘
```

---

## โดเมนที่ 1 — `identity` (ยืนยันตัวตน + สิทธิ์)

จัดการ login, สิทธิ์ และ**คำเชิญกรรมการภายนอก** (magic-link) แยกจากข้อมูลบุคลากร

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `users` | บัญชีเข้าระบบ | `id`, `email`, `password_hash`, `people_id?` (null สำหรับกรรมการนอก), `is_active` |
| `roles` | บทบาท | `id`, `code` (teacher/head/director/committee/admin), `name_th` |
| `user_roles` | ผูก user↔role (m:n) | `user_id`, `role_id`, `scope?` (เช่น dept_id ของ head) |
| `external_invitations` | เชิญกรรมการนอก | `id`, `email`, `token`, `purpose`, `expires_at`, `accepted_at?` |
| `sessions` | refresh token | `id`, `user_id`, `token_hash`, `expires_at` |

> กรรมการภายนอกไม่มี `people_id` — เข้าผ่าน magic-link, ได้ role `committee` แบบจำกัดเวลา

---

## โดเมนที่ 2 — `personnel` (ข้อมูลบุคลากร — MASTER)

แหล่งความจริงเดียวของ "คน" ในระบบ โดเมนอื่นอ้าง `people_id`

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `people` | บุคลากร | `id`, `prefix`, `first_name`, `last_name`, `position`, `rank_id`, `dept_id`, `salary_step`, `started_at` |
| `departments` | กลุ่มสาระ/ฝ่าย | `id`, `name_th`, `head_people_id?` (หัวหน้ากลุ่มสาระ) |
| `academic_ranks` | วิทยฐานะ | `id`, `code` (none/cs/csp/ce), `name_th`, `expected_level_th` |

> `departments.head_people_id` คือกุญแจของสายอนุมัติ — ระบุว่าใครเป็นหัวหน้ากลุ่มสาระ

---

## โดเมนที่ 3 — `leave` (ระบบการลา)

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `leave_types` | ประเภทการลา | `id`, `name_th`, `quota_days_per_year` |
| `leave_requests` | ใบลา | `id`, `requester_people_id`, `type_id`, `date_from`, `date_to`, `reason`, `status`, `workflow_id?` |
| `leave_balances` | สิทธิวันลาคงเหลือ | `people_id`, `type_id`, `fiscal_year`, `used_days`, `remaining_days` |

**status:** `draft` → `pending` → `approved` / `rejected` (ใช้ workflow จาก platform)

---

## โดเมนที่ 4 — `workorder` (คำสั่งปฏิบัติงาน)

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `work_orders` | คำสั่ง | `id`, `order_no`, `title`, `issuer_people_id`, `due_date`, `status` |
| `order_assignees` | ผู้รับมอบหมาย (m:n) | `work_order_id`, `people_id`, `duty` |

**status:** `new` → `in_progress` → `done`

---

## โดเมนที่ 5 — `pa` (ข้อตกลง + รายงาน + ประเมิน) ★ โดเมนหลัก

โครงสร้างซับซ้อนที่สุด — สะท้อนฟอร์มราชการ PA1ส (ข้อตกลง) + PA2 (ประเมิน)

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `pa_agreements` | ข้อตกลง 1 ฉบับ/คน/ปีงบฯ | `id`, `owner_people_id`, `fiscal_year`, `rank_id`, `status`, `approver_head_id`, `is_owner_head`, `workflow_id` |
| `pa_agreement_tasks` | งาน 3 ด้าน (ส่วนที่ 1) | `id`, `agreement_id`, `dimension` (1/2/3), `tasks`, `outcomes`, `indicators` |
| `pa_agreement_workload` | ภาระงาน | `agreement_id`, `teach_hours`, `support_hours`, `quality_hours`, `policy_hours`, `subjects` (jsonb) |
| `pa_agreement_challenge` | ประเด็นท้าทาย (ส่วนที่ 2) | `agreement_id`, `topic`, `problem`, `method`, `expect_quant`, `expect_qual` |
| `pa_reports` | รายงานผล 2 รอบ | `id`, `agreement_id`, `round` (1=มี.ค./2=ก.ย.), `status`, `notes` (jsonb ต่อด้าน), `submitted_at` |
| `pa_evaluation_assignments` | มอบหมายกรรมการ | `id`, `report_id`, `committee_user_id`, `assigned_at` |
| `pa_evaluations` | ผลประเมินของกรรมการ 1 ท่าน | `id`, `report_id`, `committee_user_id`, `submitted_at`, `total_100`, `weighted_60` |
| `pa_evaluation_scores` | คะแนนรายตัวชี้วัด | `evaluation_id`, `indicator_code`, `score`, `max_score` |
| `pa_indicators` | นิยามตัวชี้วัด (master) | `id`, `section`, `code`, `text_th`, `max_score`, `mode` (level/weighted) |

**สถานะข้อตกลง (status):** `draft` → `pending_head` → `pending_director` → `approved` (+ `returned`)
**สถานะรายงาน:** `none` → `reported` → `evaluated`

**การคิดคะแนน PA2:** ส่วนที่ 1 = 15 ตัวชี้วัด × ระดับ 1–4 รวม 60 · ส่วนที่ 2 = 40 (วิธีดำเนินการ 20 + ปริมาณ 10 + คุณภาพ 10) → รวม 100 → × 0.6 = **น้ำหนัก 60 ของ ว.PA** → เฉลี่ยจากกรรมการทุกท่าน

---

## โดเมนที่ 6 — `content` (ประกาศ + เอกสาร)

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `announcements` | ประกาศ/ข่าวสาร | `id`, `author_people_id`, `title`, `body`, `is_pinned`, `published_at` |
| `documents` | ไฟล์แนบ (polymorphic) | `id`, `owner_type`, `owner_id`, `file_url`, `mime`, `size`, `uploaded_by` |

> `documents` ใช้ร่วมทุกโดเมน: ไฟล์แนบใบลา, เอกสาร PA, ไฟล์ประกอบคำสั่ง — ผูกด้วย `owner_type`+`owner_id`

---

## โดเมนที่ 7 — `platform` (workflow + แจ้งเตือน + audit) ★ cross-cutting

หัวใจกลางที่ทุกโดเมนใช้ร่วม — โดยเฉพาะ **เครื่องมืออนุมัติหลายขั้น**

| ตาราง | คำอธิบาย | ฟิลด์สำคัญ |
|-------|----------|-----------|
| `workflow_instances` | 1 กระบวนการอนุมัติ | `id`, `subject_type` (leave/pa_agreement), `subject_id`, `current_step`, `status` |
| `workflow_steps` | แต่ละขั้น | `id`, `workflow_id`, `seq`, `approver_people_id`, `decision` (pending/approved/returned), `comment`, `decided_at` |
| `notifications` | แจ้งเตือน | `id`, `recipient_user_id`, `type`, `title`, `body`, `link`, `read_at?` |
| `audit_logs` | บันทึกกิจกรรม | `id`, `actor_user_id`, `action`, `subject_type`, `subject_id`, `meta` (jsonb), `created_at` |

**Workflow แบบหลายขั้น (PA agreement):**
```
seq 1: ผู้จัดทำ (auto-approved เมื่อ submit)
seq 2: หัวหน้ากลุ่มสาระ   ← ข้ามถ้า is_owner_head = true
seq 3: ผู้อำนวยการ
```
แต่ละขั้น decision = `returned` → ตีกลับให้แก้ไข, `approved` → ไป seq ถัดไป

---

## ตารางอ้างอิงข้ามโดเมน (Cross-domain references)

ทั้งหมดเป็น **application-level** (ไม่มี DB FK) — service ที่เป็นเจ้าของต้องตรวจสอบ integrity เอง

| จาก | ฟิลด์ | ชี้ไปยัง |
|-----|-------|---------|
| `identity.users` | `people_id` | `personnel.people.id` |
| `leave.leave_requests` | `requester_people_id` | `personnel.people.id` |
| `workorder.work_orders` | `issuer_people_id` | `personnel.people.id` |
| `pa.pa_agreements` | `owner_people_id`, `approver_head_id` | `personnel.people.id` |
| `pa.pa_evaluation_assignments` | `committee_user_id` | `identity.users.id` |
| `platform.workflow_instances` | `subject_id` | `{leave_requests \| pa_agreements}.id` |
| `platform.notifications` | `recipient_user_id` | `identity.users.id` |

> **คำแนะนำ:** ในชั้น API ให้มี read-model / view ที่ join ข้ามโดเมนผ่าน service call (หรือ DB view ตอนยังเป็น monolith) เพื่อแสดงผลบนแดชบอร์ด — แต่ "การเขียน" ต้องผ่านโดเมนเจ้าของเสมอ

---

## ลำดับการ migrate (Migration order)

เพราะมี dependency เชิงตรรกะ (ไม่ใช่ FK) แนะนำสร้างตามลำดับ:

```
1. personnel  (master — ต้องมีก่อน)
2. identity   (ผูก people_id)
3. platform   (workflow/notification ใช้โดยข้ออื่น)
4. leave · workorder · content   (ขนานกันได้)
5. pa         (ซับซ้อนสุด — พึ่ง personnel + identity + platform)
```

ดู DDL เต็มแต่ละโดเมนใน [`schema/`](./schema/)
