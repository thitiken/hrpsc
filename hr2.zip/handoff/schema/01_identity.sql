-- ============================================================
-- Domain 1: identity — ยืนยันตัวตน + สิทธิ์ + กรรมการภายนอก
-- PostgreSQL 16 · schema: identity
-- ============================================================
CREATE SCHEMA IF NOT EXISTS identity;
CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid()

-- บทบาท
CREATE TABLE identity.roles (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code        TEXT UNIQUE NOT NULL,          -- teacher | head | director | committee | admin
  name_th     TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- บัญชีผู้ใช้  (people_id = NULL สำหรับกรรมการภายนอก)
CREATE TABLE identity.users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          CITEXT UNIQUE NOT NULL,
  password_hash  TEXT,                        -- NULL ได้ ถ้าเข้าผ่าน magic-link เท่านั้น
  people_id      UUID,                        -- → personnel.people.id (app-level, no FK)
  display_name   TEXT NOT NULL,
  is_external    BOOLEAN NOT NULL DEFAULT false,
  is_active      BOOLEAN NOT NULL DEFAULT true,
  last_login_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_people ON identity.users(people_id);

-- ผูก user ↔ role (m:n)  scope = ขอบเขตสิทธิ์ เช่น dept_id ของหัวหน้ากลุ่มสาระ
CREATE TABLE identity.user_roles (
  user_id   UUID NOT NULL REFERENCES identity.users(id) ON DELETE CASCADE,
  role_id   UUID NOT NULL REFERENCES identity.roles(id) ON DELETE CASCADE,
  scope     JSONB,                            -- {"dept_id":"..."} optional
  PRIMARY KEY (user_id, role_id)
);

-- คำเชิญกรรมการภายนอก (magic-link)
CREATE TABLE identity.external_invitations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email        CITEXT NOT NULL,
  token        TEXT UNIQUE NOT NULL,
  purpose      TEXT NOT NULL,                 -- เช่น 'pa_evaluation'
  ref_id       UUID,                          -- → pa.pa_reports.id (งานที่ให้ประเมิน)
  expires_at   TIMESTAMPTZ NOT NULL,
  accepted_at  TIMESTAMPTZ,
  created_by   UUID REFERENCES identity.users(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- refresh sessions
CREATE TABLE identity.sessions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES identity.users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL,
  user_agent  TEXT,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- seed roles
INSERT INTO identity.roles(code, name_th) VALUES
  ('teacher','ครู / อาจารย์'),
  ('head','หัวหน้ากลุ่มสาระ'),
  ('director','ผู้อำนวยการ'),
  ('committee','กรรมการประเมิน'),
  ('admin','ผู้ดูแลระบบ')
ON CONFLICT (code) DO NOTHING;
