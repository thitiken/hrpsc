-- ============================================================
-- Domain 6: content — ประกาศ + เอกสารแนบ (polymorphic)
-- schema: content
-- ============================================================
CREATE SCHEMA IF NOT EXISTS content;

CREATE TABLE content.announcements (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_people_id  UUID NOT NULL,           -- → personnel.people.id
  title             TEXT NOT NULL,
  body              TEXT,
  is_pinned         BOOLEAN NOT NULL DEFAULT false,
  published_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ann_published ON content.announcements(published_at DESC);
CREATE INDEX idx_ann_pinned ON content.announcements(is_pinned);

-- ไฟล์แนบใช้ร่วมทุกโดเมน — ผูกด้วย owner_type + owner_id (app-level)
CREATE TABLE content.documents (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_type   TEXT NOT NULL,                -- leave_request | pa_agreement | pa_report | work_order | announcement
  owner_id     UUID NOT NULL,
  file_url     TEXT NOT NULL,                -- S3/MinIO key
  file_name    TEXT NOT NULL,
  mime         TEXT,
  size_bytes   BIGINT,
  uploaded_by  UUID,                         -- → identity.users.id
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_doc_owner ON content.documents(owner_type, owner_id);
