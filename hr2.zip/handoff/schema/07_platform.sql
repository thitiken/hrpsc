-- ============================================================
-- Domain 7: platform — workflow + แจ้งเตือน + audit (★ cross-cutting)
-- schema: platform  ·  ใช้ร่วมทุกโดเมน
-- ============================================================
CREATE SCHEMA IF NOT EXISTS platform;

-- 1 กระบวนการอนุมัติ (polymorphic subject)
CREATE TABLE platform.workflow_instances (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type  TEXT NOT NULL,               -- leave_request | pa_agreement
  subject_id    UUID NOT NULL,
  current_step  SMALLINT NOT NULL DEFAULT 1,
  status        TEXT NOT NULL DEFAULT 'running', -- running | approved | returned | cancelled
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_wf_subject ON platform.workflow_instances(subject_type, subject_id);

-- แต่ละขั้นของ workflow
CREATE TABLE platform.workflow_steps (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id         UUID NOT NULL REFERENCES platform.workflow_instances(id) ON DELETE CASCADE,
  seq                 SMALLINT NOT NULL,     -- 1=ผู้จัดทำ 2=หัวหน้ากลุ่มสาระ 3=ผอ.
  role_code           TEXT NOT NULL,         -- teacher | head | director
  approver_people_id  UUID,                  -- → personnel.people.id
  decision            TEXT NOT NULL DEFAULT 'pending', -- pending | approved | returned | skipped
  comment             TEXT,
  decided_at          TIMESTAMPTZ,
  UNIQUE (workflow_id, seq)
);

-- แจ้งเตือน
CREATE TABLE platform.notifications (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_user_id  UUID NOT NULL,          -- → identity.users.id
  type               TEXT NOT NULL,          -- leave_pending | pa_returned | pa_approved | ...
  title              TEXT NOT NULL,
  body               TEXT,
  link               TEXT,                   -- deep link ในแอป
  read_at            TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notif_recipient ON platform.notifications(recipient_user_id, read_at);

-- บันทึกกิจกรรม (audit trail)
CREATE TABLE platform.audit_logs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID,                        -- → identity.users.id
  action        TEXT NOT NULL,               -- create | update | submit | approve | return | delete
  subject_type  TEXT NOT NULL,
  subject_id    UUID,
  meta          JSONB,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_subject ON platform.audit_logs(subject_type, subject_id);
CREATE INDEX idx_audit_actor ON platform.audit_logs(actor_user_id);
CREATE INDEX idx_audit_time ON platform.audit_logs(created_at DESC);
