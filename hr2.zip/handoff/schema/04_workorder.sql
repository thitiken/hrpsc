-- ============================================================
-- Domain 4: workorder — คำสั่งปฏิบัติงาน
-- schema: workorder
-- ============================================================
CREATE SCHEMA IF NOT EXISTS workorder;

CREATE TABLE workorder.work_orders (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_no          TEXT NOT NULL,            -- เลขที่คำสั่ง เช่น 045/2569
  title             TEXT NOT NULL,
  description       TEXT,
  issuer_people_id  UUID NOT NULL,            -- → personnel.people.id
  due_date          DATE,
  status            TEXT NOT NULL DEFAULT 'new',  -- new|in_progress|done
  fiscal_year       INTEGER,                  -- พ.ศ.
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_wo_status ON workorder.work_orders(status);
CREATE INDEX idx_wo_year ON workorder.work_orders(fiscal_year);

CREATE TABLE workorder.order_assignees (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  work_order_id  UUID NOT NULL REFERENCES workorder.work_orders(id) ON DELETE CASCADE,
  people_id      UUID NOT NULL,              -- → personnel.people.id
  duty           TEXT,                        -- หน้าที่ในคำสั่ง
  UNIQUE (work_order_id, people_id)
);
CREATE INDEX idx_assignee_people ON workorder.order_assignees(people_id);
