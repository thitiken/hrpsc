-- ============================================================
-- Domain 3: leave — ระบบการลา
-- schema: leave
-- ============================================================
CREATE SCHEMA IF NOT EXISTS leave;

CREATE TABLE leave.leave_types (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_th              TEXT NOT NULL,          -- ลาป่วย/ลากิจ/ลาพักผ่อน
  quota_days_per_year  INTEGER,
  is_active            BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE leave.leave_requests (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_people_id  UUID NOT NULL,          -- → personnel.people.id
  type_id              UUID NOT NULL REFERENCES leave.leave_types(id),
  date_from            DATE NOT NULL,
  date_to              DATE NOT NULL,
  days                 NUMERIC(4,1) NOT NULL,
  reason               TEXT,
  status               TEXT NOT NULL DEFAULT 'draft',  -- draft|pending|approved|rejected
  workflow_id          UUID,                   -- → platform.workflow_instances.id
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (date_to >= date_from)
);
CREATE INDEX idx_leave_requester ON leave.leave_requests(requester_people_id);
CREATE INDEX idx_leave_status ON leave.leave_requests(status);

CREATE TABLE leave.leave_balances (
  people_id       UUID NOT NULL,              -- → personnel.people.id
  type_id         UUID NOT NULL REFERENCES leave.leave_types(id),
  fiscal_year     INTEGER NOT NULL,           -- พ.ศ.
  used_days       NUMERIC(5,1) NOT NULL DEFAULT 0,
  remaining_days  NUMERIC(5,1) NOT NULL DEFAULT 0,
  PRIMARY KEY (people_id, type_id, fiscal_year)
);

INSERT INTO leave.leave_types(name_th, quota_days_per_year) VALUES
  ('ลาป่วย', 60), ('ลากิจส่วนตัว', 45), ('ลาพักผ่อน', 10)
ON CONFLICT DO NOTHING;
