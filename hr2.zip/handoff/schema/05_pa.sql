-- ============================================================
-- Domain 5: pa — ข้อตกลงพัฒนางาน + รายงานผล + ประเมิน (★ โดเมนหลัก)
-- schema: pa  ·  สะท้อนฟอร์ม PA1ส (ข้อตกลง) + PA2 (ประเมิน)
-- ============================================================
CREATE SCHEMA IF NOT EXISTS pa;

-- ---------- master: นิยามตัวชี้วัด PA2 ----------
CREATE TABLE pa.pa_indicators (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section     SMALLINT NOT NULL,             -- 1 (มาตรฐานตำแหน่ง) | 2 (ประเด็นท้าทาย)
  code        TEXT NOT NULL,                 -- 1.1 .. 3.3  หรือ  1/2.1/2.2
  text_th     TEXT NOT NULL,
  max_score   SMALLINT NOT NULL,             -- 4 (level) หรือ 20/10 (weighted)
  mode        TEXT NOT NULL,                 -- level | weighted
  sort        SMALLINT NOT NULL DEFAULT 0
);

-- ---------- ข้อตกลง 1 ฉบับ ต่อคน ต่อปีงบประมาณ ----------
CREATE TABLE pa.pa_agreements (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_people_id   UUID NOT NULL,           -- → personnel.people.id (เจ้าของ)
  fiscal_year       INTEGER NOT NULL,        -- พ.ศ.
  rank_id           UUID,                    -- → personnel.academic_ranks.id (snapshot)
  date_from         DATE,
  date_to           DATE,
  rooms             JSONB,                   -- ประเภทห้องเรียน (array)
  status            TEXT NOT NULL DEFAULT 'draft',
      -- draft | pending_head | pending_director | approved | returned
  approver_head_id  UUID,                    -- → personnel.people.id (หัวหน้ากลุ่มสาระที่เลือก)
  is_owner_head     BOOLEAN NOT NULL DEFAULT false,  -- ผู้จัดทำเป็นหัวหน้าเอง → ข้ามขั้น head
  returned_by       TEXT,                    -- head | director (เมื่อ status=returned)
  return_note       TEXT,
  workflow_id       UUID,                    -- → platform.workflow_instances.id
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner_people_id, fiscal_year)
);
CREATE INDEX idx_pa_owner ON pa.pa_agreements(owner_people_id);
CREATE INDEX idx_pa_year ON pa.pa_agreements(fiscal_year);
CREATE INDEX idx_pa_status ON pa.pa_agreements(status);

-- ภาระงาน (ส่วนที่ 1 หัวตาราง)
CREATE TABLE pa.pa_agreement_workload (
  agreement_id   UUID PRIMARY KEY REFERENCES pa.pa_agreements(id) ON DELETE CASCADE,
  teach_hours    NUMERIC(4,1),
  support_hours  NUMERIC(4,1),
  quality_hours  NUMERIC(4,1),
  policy_hours   NUMERIC(4,1),
  subjects       JSONB                       -- [{name, hours}, ...]
);

-- งาน 3 ด้าน (ส่วนที่ 1)
CREATE TABLE pa.pa_agreement_tasks (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id  UUID NOT NULL REFERENCES pa.pa_agreements(id) ON DELETE CASCADE,
  dimension     SMALLINT NOT NULL,           -- 1 | 2 | 3
  tasks         TEXT,                        -- งานที่จะพัฒนา
  outcomes      TEXT,                        -- ผลลัพธ์ที่คาดหวัง
  indicators    TEXT,                        -- ตัวชี้วัด
  UNIQUE (agreement_id, dimension)
);

-- ประเด็นท้าทาย (ส่วนที่ 2)
CREATE TABLE pa.pa_agreement_challenge (
  agreement_id   UUID PRIMARY KEY REFERENCES pa.pa_agreements(id) ON DELETE CASCADE,
  topic          TEXT,
  problem        TEXT,
  method         TEXT,
  expect_quant   TEXT,                        -- ผลลัพธ์เชิงปริมาณ
  expect_qual    TEXT                         -- ผลลัพธ์เชิงคุณภาพ
);

-- ---------- รายงานผล 2 รอบ ----------
CREATE TABLE pa.pa_reports (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id  UUID NOT NULL REFERENCES pa.pa_agreements(id) ON DELETE CASCADE,
  round         SMALLINT NOT NULL,           -- 1 = สิ้น มี.ค. | 2 = สิ้น ก.ย.
  status        TEXT NOT NULL DEFAULT 'none',-- none | reported | evaluated
  notes         JSONB,                       -- {d1,d2,d3,s2} ผลการปฏิบัติจริงต่อด้าน
  submitted_at  TIMESTAMPTZ,
  UNIQUE (agreement_id, round)
);
CREATE INDEX idx_report_status ON pa.pa_reports(status);

-- ---------- มอบหมายกรรมการ (รวมกรรมการภายนอก) ----------
CREATE TABLE pa.pa_evaluation_assignments (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id          UUID NOT NULL REFERENCES pa.pa_reports(id) ON DELETE CASCADE,
  committee_user_id  UUID NOT NULL,          -- → identity.users.id (อาจเป็นบุคคลภายนอก)
  assigned_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (report_id, committee_user_id)
);

-- ---------- ผลประเมินของกรรมการ 1 ท่าน ----------
CREATE TABLE pa.pa_evaluations (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id          UUID NOT NULL REFERENCES pa.pa_reports(id) ON DELETE CASCADE,
  committee_user_id  UUID NOT NULL,          -- → identity.users.id
  total_100          NUMERIC(5,2),           -- รวม 100
  weighted_60        NUMERIC(5,2),           -- × 0.6
  comment            TEXT,
  submitted_at       TIMESTAMPTZ,
  UNIQUE (report_id, committee_user_id)
);

-- คะแนนรายตัวชี้วัด
CREATE TABLE pa.pa_evaluation_scores (
  evaluation_id   UUID NOT NULL REFERENCES pa.pa_evaluations(id) ON DELETE CASCADE,
  indicator_code  TEXT NOT NULL,             -- อ้าง pa_indicators.code (snapshot)
  score           NUMERIC(4,1) NOT NULL,
  max_score       SMALLINT NOT NULL,
  PRIMARY KEY (evaluation_id, indicator_code)
);

-- ---------- View: คะแนนเฉลี่ยจากกรรมการทุกท่าน (read-model) ----------
CREATE VIEW pa.v_report_final_score AS
SELECT r.id            AS report_id,
       r.agreement_id,
       COUNT(e.id)                      AS committee_count,
       ROUND(AVG(e.total_100), 2)       AS avg_total_100,
       ROUND(AVG(e.weighted_60), 2)     AS avg_weighted_60
FROM pa.pa_reports r
LEFT JOIN pa.pa_evaluations e
       ON e.report_id = r.id AND e.submitted_at IS NOT NULL
GROUP BY r.id, r.agreement_id;
