-- ============================================================
-- Domain 2: personnel — ข้อมูลบุคลากร (MASTER)
-- schema: personnel  ·  แหล่งความจริงเดียวของ "คน"
-- ============================================================
CREATE SCHEMA IF NOT EXISTS personnel;

-- วิทยฐานะ
CREATE TABLE personnel.academic_ranks (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code               TEXT UNIQUE NOT NULL,    -- none | cs | csp | ce
  name_th            TEXT NOT NULL,
  expected_level_th  TEXT NOT NULL            -- ระดับการปฏิบัติที่คาดหวัง
);

-- กลุ่มสาระ / ฝ่าย  (head_people_id = หัวหน้ากลุ่มสาระ → สายอนุมัติ PA)
CREATE TABLE personnel.departments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_th         TEXT NOT NULL,
  head_people_id  UUID,                        -- → personnel.people.id (self, app-level)
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- บุคลากร
CREATE TABLE personnel.people (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prefix       TEXT NOT NULL,                  -- นาย/นาง/นางสาว
  first_name   TEXT NOT NULL,
  last_name    TEXT NOT NULL,
  position     TEXT NOT NULL DEFAULT 'ครู',
  rank_id      UUID REFERENCES personnel.academic_ranks(id),
  dept_id      UUID REFERENCES personnel.departments(id),
  salary_step  TEXT,                           -- เช่น คศ.1
  salary_baht  NUMERIC(12,2),
  email        CITEXT,
  phone        TEXT,
  started_at   DATE,
  is_active    BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_people_dept ON personnel.people(dept_id);
CREATE INDEX idx_people_name ON personnel.people(first_name, last_name);

-- seed ranks
INSERT INTO personnel.academic_ranks(code, name_th, expected_level_th) VALUES
  ('none','ครู (ยังไม่มีวิทยฐานะ)','ปรับประยุกต์'),
  ('cs','ครูชำนาญการ','แก้ไขปัญหา'),
  ('csp','ครูชำนาญการพิเศษ','ริเริ่ม พัฒนา'),
  ('ce','ครูเชี่ยวชาญ','คิดค้น ปรับเปลี่ยน')
ON CONFLICT (code) DO NOTHING;
