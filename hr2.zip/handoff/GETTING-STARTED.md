# เริ่มต้นใช้งานกับ Claude Code (Getting Started)

> คู่มือ 6 เฟส — ทำทีละเฟส ตรวจงานก่อนไปต่อ คำสั่งทุกอันก๊อปวางได้เลย

---

## ขั้นเตรียม (ทำครั้งเดียว)

1. แตกไฟล์ `handoff/` ไว้ในโฟลเดอร์โปรเจกต์ใหม่ เช่น `school-hr/`
2. ติดตั้ง Claude Code (ถ้ายังไม่มี): `npm install -g @anthropic-ai/claude-code`
3. เปิดเทอร์มินัลที่โฟลเดอร์นั้น:
   ```bash
   cd school-hr
   claude
   ```

---

## เฟส 1 — Scaffold โครงโปรเจกต์
```
อ่าน handoff/README.md แล้วเริ่มจากเฟส 1: สร้างโครง monorepo
(React+Vite+TS web, NestJS api, Prisma multi-schema, docker-compose postgres+minio)
ตามโครงสร้างในข้อ 4 ของ README
```
✅ ตรวจ: มีโฟลเดอร์ `apps/web`, `apps/api`, `packages/shared`, `docker-compose.yml`
รัน `docker compose up -d` แล้ว postgres + minio ขึ้น

---

## เฟส 2 — Database
```
อ่าน handoff/DATA-ARCHITECTURE.md และ handoff/schema/*.sql
สร้าง Prisma schema แบบ multi-schema ครบทั้ง 7 โดเมน
อ้างอิงข้ามโดเมนด้วย UUID เท่านั้น (ห้ามมี FK ข้ามโดเมน)
แล้วทำ migration + seed (roles, ranks, leave_types)
```
✅ ตรวจ: `npx prisma migrate dev` ผ่าน · เห็น 7 schema ใน DB

---

## เฟส 3 — Design System + UI Kit
```
อ่าน handoff/README.md ข้อ 5 และ handoff/design/HR Dashboard.html
ตั้งค่า Tailwind + CSS variables จาก design tokens (รวมโหมดมืด)
สร้าง UI kit: Button, Card, Modal (confirm + success), StatusPill, Toast, Input
ใช้ฟอนต์ Prompt + IBM Plex Sans Thai, ไอคอน Lucide
```
✅ ตรวจ: เปิด Storybook/หน้า demo เทียบกับ `design/HR Dashboard.html` แล้วหน้าตาตรง

---

## เฟส 4 — Auth (identity)
```
ทำ identity module ตาม handoff/API-SPEC.md หัวข้อ identity:
JWT (access+refresh), role guard (teacher/head/director/committee/admin),
และ magic-link สำหรับกรรมการภายนอก
```
✅ ตรวจ: login ได้, /auth/me คืน roles, magic-link ใช้ได้

---

## เฟส 5 — โดเมนทีละตัว
ทำเรียงทีละโดเมน (backend module + endpoints → frontend หน้าจอ):
```
ทำโดเมน personnel ตาม API-SPEC.md + ผูกหน้า "ข้อมูลบุคลากร" ใน design/
```
แล้วทำตามลำดับ: **personnel → leave → workorder → pa → committee**
สำหรับ pa และ committee ให้ดู `design/pa-module.js` (การไหลของสถานะ)
และ `design/PA Committee Portal.html` (ฟอร์มให้คะแนน)
```
ทำโดเมน pa: ข้อตกลง PA1ส + สายอนุมัติ 2 ขั้น (ครู→หัวหน้ากลุ่มสาระ→ผอ.)
+ รายงานผล 2 รอบ ตาม design/pa-module.js
```
✅ ตรวจ: สร้างข้อตกลง → ส่ง → อนุมัติ → รายงาน → ประเมิน ครบ flow

---

## เฟส 6 — Workflow Engine
```
ทำ platform.workflow ให้ leave และ pa_agreement ใช้ engine อนุมัติร่วมกัน
(workflow_instances + workflow_steps) รองรับข้ามขั้นเมื่อผู้จัดทำเป็นหัวหน้าเอง
และการตีกลับให้แก้ไข + แจ้งเตือน + audit log
```
✅ ตรวจ: ตีกลับ/ส่งใหม่ได้, แจ้งเตือนเด้ง, audit log บันทึกทุกการตัดสิน

---

## เคล็ดลับ
- **ทีละเฟส** — อย่ารวบหลายเฟสในคำสั่งเดียว
- ให้ Claude Code **อ่าน `design/` ก่อนทำ frontend** ทุกครั้ง
- ขอให้เขียน **test** ของแต่ละ endpoint ก่อนต่อโดเมนถัดไป
- ติดปัญหา schema → ชี้กลับไปที่ `schema/<โดเมน>.sql` เป็นความจริงอ้างอิง
