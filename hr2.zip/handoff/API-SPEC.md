# API Specification (REST)

> Base URL: `/api/v1` · Auth: `Authorization: Bearer <access_token>` (ยกเว้น auth + magic-link)
> ทุก response เป็น JSON · วันที่ใน payload เป็น ISO-8601 (UTC); แปลงเป็น พ.ศ. ที่ frontend

แบ่ง endpoint ตามโดเมน — แต่ละกลุ่มควรเป็น module/controller แยกใน NestJS

---

## identity

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| POST | `/auth/login` | email+password → access+refresh | public |
| POST | `/auth/refresh` | refresh → access ใหม่ | public |
| POST | `/auth/logout` | เพิกถอน session | auth |
| GET  | `/auth/me` | ข้อมูลผู้ใช้ + roles + people | auth |
| POST | `/invitations` | เชิญกรรมการภายนอก (สร้าง magic-link) | admin |
| POST | `/auth/magic/:token` | กรรมการนอกเข้าระบบผ่านลิงก์ | public |

```jsonc
// POST /auth/login → 200
{ "accessToken":"...", "refreshToken":"...",
  "user":{ "id":"...", "displayName":"ธิติวัฒน์ ทองคำ",
           "roles":["teacher"], "peopleId":"...", "isExternal":false } }
```

---

## personnel

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/people` | รายชื่อบุคลากร (ค้นหา/กรองกลุ่มสาระ) | head, admin |
| GET  | `/people/:id` | รายละเอียด 1 คน | auth |
| POST | `/people` · PATCH `/people/:id` | สร้าง/แก้ไข | admin |
| GET  | `/departments` | กลุ่มสาระ + หัวหน้า | auth |
| GET  | `/ranks` | วิทยฐานะ + ระดับที่คาดหวัง | auth |

---

## leave

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/leave/requests?mine=1` | ใบลาของฉัน | teacher+ |
| GET  | `/leave/requests?status=pending` | คิวรออนุมัติ | head, director, admin |
| POST | `/leave/requests` | สร้างใบลา (draft) | teacher+ |
| POST | `/leave/requests/:id/submit` | ส่งเข้าสู่ workflow | teacher+ |
| POST | `/leave/requests/:id/decision` | อนุมัติ/ตีกลับ (ผ่าน workflow) | head, director |
| GET  | `/leave/balances?peopleId=&year=` | สิทธิวันลาคงเหลือ | auth |

---

## workorder

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/work-orders?mine=1` | คำสั่งที่ได้รับมอบหมาย | teacher+ |
| GET  | `/work-orders` | ทั้งหมด (กรองปี/สถานะ) | admin |
| POST | `/work-orders` | ออกคำสั่ง + มอบหมาย | admin |
| PATCH| `/work-orders/:id/status` | อัปเดตสถานะ | admin |

---

## pa  (★ โดเมนหลัก)

### ข้อตกลง (agreement)
| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/pa/agreements?year=2569&mine=1` | ข้อตกลงของฉันรายปี | teacher+ |
| POST | `/pa/agreements` | สร้างข้อตกลงปีงบฯ | teacher+ |
| PATCH| `/pa/agreements/:id` | บันทึกร่าง (tasks/workload/challenge) | owner |
| POST | `/pa/agreements/:id/submit` | ส่งเข้าสายอนุมัติ (head→director หรือ ข้าม) | owner |
| POST | `/pa/agreements/:id/decision` | head/director เห็นชอบ/ตีกลับ | head, director |

```jsonc
// POST /pa/agreements/:id/submit
{ "approverHeadId":"<people_id>", "isOwnerHead": false }
// ถ้า isOwnerHead=true → ข้ามขั้นหัวหน้ากลุ่มสาระ ไป director ตรง
```

### รายงานผล (report)
| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/pa/agreements/:id/reports` | รายงาน 2 รอบ | owner, committee, admin |
| PATCH| `/pa/reports/:id` | บันทึกผลรอบนั้น (ก่อนส่ง) | owner |
| POST | `/pa/reports/:id/submit` | ส่งให้คณะกรรมการ | owner |

### ประเมิน (PA2)
| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| POST | `/pa/reports/:id/assign` | มอบหมายกรรมการ (รวมภายนอก) | admin |
| GET  | `/pa/committee/queue` | งานที่ฉัน(กรรมการ)ต้องประเมิน | committee |
| GET  | `/pa/reports/:id/evaluation-form` | ฟอร์ม + ตัวชี้วัดตามวิทยฐานะ | committee |
| POST | `/pa/reports/:id/evaluate` | ส่งคะแนน (รายตัวชี้วัด) | committee |
| GET  | `/pa/reports/:id/final-score` | คะแนนเฉลี่ยจากกรรมการ (view) | owner, admin |

```jsonc
// POST /pa/reports/:id/evaluate
{ "scores":[ {"indicatorCode":"1.1","score":4,"maxScore":4}, ... ],
  "comment":"งานสอดคล้องกับมาตรฐานตำแหน่ง" }
// → server คำนวณ total_100 และ weighted_60 (×0.6) เอง
```

---

## content

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/announcements?pinned=1` | ประกาศ (ปักหมุดก่อน) | auth |
| POST | `/announcements` | สร้างประกาศ | head, admin |
| POST | `/documents` (multipart) | อัปโหลดไฟล์แนบ (owner_type+owner_id) | auth |
| GET  | `/documents?ownerType=&ownerId=` | ไฟล์แนบของรายการ | auth |

---

## platform

| Method | Path | คำอธิบาย | Role |
|--------|------|----------|------|
| GET  | `/workflows/:id` | สถานะ + ทุกขั้นของ workflow | auth |
| GET  | `/notifications?unread=1` | แจ้งเตือนของฉัน | auth |
| POST | `/notifications/:id/read` | ทำเครื่องหมายอ่าน | auth |
| GET  | `/audit-logs?subjectType=&subjectId=` | ประวัติของรายการ | admin |

---

## รูปแบบ error มาตรฐาน

```jsonc
// 4xx/5xx
{ "error": { "code":"FORBIDDEN", "message":"ไม่มีสิทธิ์เข้าถึงรายการนี้",
             "details": null } }
```

| HTTP | code | ใช้เมื่อ |
|------|------|---------|
| 400 | `VALIDATION_ERROR` | payload ไม่ผ่าน validation |
| 401 | `UNAUTHORIZED` | ไม่มี/หมดอายุ token |
| 403 | `FORBIDDEN` | role ไม่พอ / ไม่ใช่เจ้าของ |
| 404 | `NOT_FOUND` | ไม่พบรายการ |
| 409 | `CONFLICT` | เช่น ข้อตกลงปีงบฯ นั้นมีแล้ว |
