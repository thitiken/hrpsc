# ระบบบริหารงานบุคลากรโรงเรียน (School HR & PA System)

> **Developer Handoff Package** — สำหรับพัฒนาต่อด้วย Claude Code
> โรงเรียนสิรินธรราชวิทยาลัย · ระบบบริหารงานบุคลากร + ข้อตกลงพัฒนางาน (ว.PA)

---

## 1. ภาพรวมระบบ (What this is)

ระบบบริหารงานบุคลากรภายในโรงเรียนระดับมัธยม ครอบคลุม:

- **ระบบการลา** — ครูยื่นใบลา → อนุมัติแบบหลายขั้น
- **คำสั่งปฏิบัติงาน** — Admin ออกคำสั่ง มอบหมายครู
- **ข้อตกลงพัฒนางาน (PA / ว.PA)** — หัวใจของระบบ
  - ครูจัดทำ **ข้อตกลง PA1ส** รายปีงบประมาณ
  - สายอนุมัติ 2 ขั้น: **ครู → หัวหน้ากลุ่มสาระ → ผู้อำนวยการ**
  - ครู **รายงานผล 2 รอบ** (สิ้น มี.ค. และ สิ้น ก.ย.)
  - **คณะกรรมการประเมิน (PA2)** — รวมถึงกรรมการ**ภายนอก**องค์กร — ให้คะแนนตามตัวชี้วัด (15 ข้อ ระดับ 1–4 = 60 คะแนน + ประเด็นท้าทาย 40 คะแนน) แล้วเฉลี่ยรวม
- **ประกาศ/ข่าวสาร** + **แดชบอร์ดภาพรวม**

### บทบาทผู้ใช้ (Roles)

| Role | คำอธิบาย | สิทธิ์โดยย่อ |
|------|----------|-------------|
| `teacher` | ครู / อาจารย์ | บันทึก/แก้ไขข้อมูลของตน · ยื่นคำขอ · รายงานผล PA |
| `head` | หัวหน้ากลุ่มสาระ | สิทธิ์ teacher ครบ **+** อนุมัติขั้นแรกก่อนส่ง ผอ. |
| `director` | ผู้อำนวยการ | อนุมัติขั้นสุดท้าย |
| `committee` | กรรมการประเมิน (อาจเป็น**บุคคลภายนอก**) | เห็นเฉพาะรายงานผลที่ได้รับมอบหมาย + ให้คะแนน PA2 |
| `admin` | ผู้ดูแลระบบ | จัดการข้อมูลทั้งหมด · ตรวจสอบ · ตั้งค่ารอบ/มอบหมายกรรมการ |

---

## 2. สถาปัตยกรรมข้อมูล (Data Architecture)

ออกแบบแบบ **Database-per-Domain (Bounded Context)** — แยกฐานข้อมูล/สคีมาตามขอบเขตงาน
อ่านรายละเอียดเต็มใน [`DATA-ARCHITECTURE.md`](./DATA-ARCHITECTURE.md) และ DDL ใน [`schema/`](./schema/)

| # | Database / Schema | ขอบเขตงาน | ตารางหลัก |
|---|-------------------|-----------|-----------|
| 1 | **`identity`** | ยืนยันตัวตน + สิทธิ์ | `users`, `roles`, `user_roles`, `sessions`, `external_invitations` |
| 2 | **`personnel`** | ข้อมูลบุคลากร (master) | `people`, `departments`, `academic_ranks` |
| 3 | **`leave`** | ระบบการลา | `leave_requests`, `leave_types`, `leave_balances` |
| 4 | **`workorder`** | คำสั่งปฏิบัติงาน | `work_orders`, `order_assignees` |
| 5 | **`pa`** | ข้อตกลง + รายงาน + ประเมิน | `pa_agreements`, `pa_reports`, `pa_evaluations`, `pa_evaluation_scores`, … |
| 6 | **`content`** | ประกาศ + เอกสาร | `announcements`, `documents` |
| 7 | **`platform`** | workflow + แจ้งเตือน + audit | `workflow_instances`, `workflow_steps`, `notifications`, `audit_logs` |

> **กฎเหล็ก:** ไม่มี Foreign Key ข้ามขอบเขตฐานข้อมูล — อ้างอิงข้ามด้วย **ID (UUID) เท่านั้น**
> เช่น `pa.pa_agreements.owner_people_id` ชี้ไปยัง `personnel.people.id` ในระดับแอปพลิเคชัน ไม่ใช่ DB constraint
> ทำให้แยกเป็น microservice แยก deploy ได้ในอนาคตโดยไม่ต้องแก้ schema

### เริ่มจาก Modular Monolith

แนะนำเริ่มที่ **modular monolith** — PostgreSQL instance เดียว แยกเป็น 7 **schema** (ไม่ใช่ 7 server) แต่ละโดเมนเป็น module แยกในโค้ด ขอบเขตชัด พอโตค่อยแยกเป็น service จริงทีหลัง (schema → database ได้ตรง ๆ)

---

## 3. Tech Stack ที่แนะนำ

| ชั้น | เทคโนโลยี | เหตุผล |
|------|-----------|--------|
| Frontend | **React 18 + TypeScript + Vite** | โครงปัจจุบันเป็น component-based อยู่แล้ว |
| Styling | **Tailwind CSS** (+ CSS variables) | map ตรงกับ design tokens เดิม (ดูข้อ 5) |
| State/Data | **TanStack Query** + Zustand | server-state + UI-state แยกกัน |
| Backend | **NestJS (Node + TypeScript)** | โครง module ตรงกับ bounded context |
| ORM | **Prisma** (multi-schema) หรือ Drizzle | รองรับ multi-schema PostgreSQL |
| Database | **PostgreSQL 16** (7 schemas) | JSONB, transaction, แยก schema ได้ |
| Auth | **JWT (access+refresh)** | + **magic-link** สำหรับกรรมการภายนอก |
| Files | **S3-compatible (MinIO)** | เก็บไฟล์แนบ PA / เอกสาร |
| i18n | ภาษาไทยเป็นหลัก | ปี **พ.ศ.** (Buddhist calendar) ทั้งระบบ |

---

## 4. โครงสร้างโปรเจกต์ที่แนะนำ (Suggested layout)

```
school-hr/
├── apps/
│   ├── web/                    # React frontend
│   │   ├── src/
│   │   │   ├── modules/        # 1 โฟลเดอร์ต่อ domain
│   │   │   │   ├── dashboard/
│   │   │   │   ├── leave/
│   │   │   │   ├── workorder/
│   │   │   │   ├── pa/          # agreement + reports
│   │   │   │   ├── committee/   # หน้ากรรมการ PA2
│   │   │   │   └── admin/
│   │   │   ├── components/      # ui kit (Button, Card, Modal, …)
│   │   │   ├── lib/             # api client, date(พ.ศ.), auth
│   │   │   └── styles/tokens.css
│   └── api/                    # NestJS backend
│       └── src/modules/        # identity, personnel, leave, workorder, pa, content, platform
├── packages/
│   └── shared/                 # types, DTOs, enums ใช้ร่วม web+api
├── prisma/
│   └── schema.prisma           # multi-schema (ดู schema/*.sql เป็น reference)
└── docker-compose.yml          # postgres + minio
```

---

## 5. Design System (นำมาจากดีไซน์ที่อนุมัติแล้ว)

ไฟล์ดีไซน์ที่ผ่านการรีวิวอยู่ใน [`design/`](./design/) — ใช้เป็น **source of truth** ของ UI

### Color tokens (oklch)
```css
--brand:        oklch(0.52 0.17 292);   /* ม่วงแบรนด์โรงเรียน */
--brand-600:    oklch(0.47 0.17 292);
--brand-700:    oklch(0.41 0.16 292);
--brand-400:    oklch(0.62 0.16 292);
--brand-soft:   oklch(0.95 0.035 292);
--ink:          oklch(0.27 0.025 292);   /* ตัวอักษรหลัก */
--muted:        oklch(0.58 0.018 292);
--line:         oklch(0.92 0.012 292);
--green: oklch(0.62 0.14 155);  --amber: oklch(0.72 0.14 75);
--rose:  oklch(0.6 0.16 18);    --blue:  oklch(0.6 0.13 250);
```
รองรับ **โหมดมืด** แล้ว — override ผ่าน `html[data-theme="dark"]` (ดูใน `design/HR Dashboard.html`)

### Type
- หัวเรื่อง/ตัวเลข: **Prompt**
- เนื้อหา: **IBM Plex Sans Thai**
- โค้ด/รหัสฟิลด์: **JetBrains Mono**

### หลักการ UI
- การ์ดมุมโค้งนุ่ม (radius 11–22px) เงาฟุ้งเบา ระยะหายใจเยอะ
- ไอคอนเส้น **Lucide** (ไม่ใช้อีโมจิ)
- ปุ่มส่งคำขอ → **ป๊อบอัปยืนยันก่อนส่ง** แล้ว **ป๊อบอัปยืนยันสำเร็จ** (ระบุงาน + ผู้รับ + เวลา)
- ยืนยันก่อนลบทุกครั้ง · นาฬิกา/วันที่เป็น **พ.ศ.**

---

## 6. ทำงานกับ Claude Code อย่างไร (Getting started)

แนะนำสั่งงานเป็นเฟส ตามลำดับนี้:

1. **Scaffold** — _"สร้างโครง monorepo ตาม README ข้อ 4 (React+Vite web, NestJS api, Prisma multi-schema, docker-compose postgres+minio)"_
2. **Database** — _"สร้าง Prisma schema จากไฟล์ DDL ใน `schema/` ทั้ง 7 โดเมน อ้างอิงข้ามด้วย ID เท่านั้น"_
3. **Design system** — _"ตั้งค่า Tailwind + CSS tokens จาก README ข้อ 5 และสร้าง UI kit: Button, Card, Modal(confirm), StatusPill, Toast"_
4. **Auth** — _"ทำ identity module: JWT + role guard + magic-link สำหรับ committee ภายนอก ตาม API-SPEC.md"_
5. **โดเมนทีละตัว** — personnel → leave → workorder → pa → committee เริ่มจาก backend module + endpoints แล้วต่อ frontend (ดูดีไซน์ใน `design/`)
6. **Workflow engine** — _"ทำ platform.workflow ให้ leave และ pa_agreement ใช้ร่วมกัน (multi-step approval)"_

> เริ่มอ่าน 3 ไฟล์นี้ก่อนเสมอ: `README.md` → `DATA-ARCHITECTURE.md` → `API-SPEC.md`
> ดู UI/UX จริงได้จาก `design/*.html` (เปิดในเบราว์เซอร์)

---

## 7. ไฟล์ในแพ็กเกจนี้

```
handoff/
├── README.md                 ← (ไฟล์นี้) ภาพรวม + tech stack + วิธีเริ่ม
├── DATA-ARCHITECTURE.md      ← การแยก 7 โดเมน + ERD + cross-DB refs + กฎ
├── API-SPEC.md               ← REST endpoints ต่อ service + ตัวอย่าง payload
├── schema/                   ← PostgreSQL DDL (1 ไฟล์ต่อโดเมน)
│   ├── 01_identity.sql
│   ├── 02_personnel.sql
│   ├── 03_leave.sql
│   ├── 04_workorder.sql
│   ├── 05_pa.sql
│   ├── 06_content.sql
│   └── 07_platform.sql
└── design/                   ← ดีไซน์ที่อนุมัติแล้ว (HTML, เปิดดูได้)
    ├── HR Dashboard.html     ← แดชบอร์ด + โมดูล PA (light/dark)
    ├── pa-module.js          ← logic หน้า PA (อ่านเป็น reference การไหลของสถานะ)
    ├── PA Committee Portal.html  ← หน้ากรรมการให้คะแนน PA2
    └── Data Architecture.html    ← เอกสารสถาปัตยกรรมเชิงภาพ (เวอร์ชันแสดงผล)
```
